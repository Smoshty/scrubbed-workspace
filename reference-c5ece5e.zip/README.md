# Optional Scrubbed Workspace reference

Code exported from source commit `c5ece5ed7d9f708415d664b1f2a39ed93f2faba5`.

From the extracted folder, run:

```sh
mkdir -p data
python3 -m unittest discover -s tests -p test_workspace_view.py -v
```

These are controlled synthetic checks of held messages, checked-copy access,
delivery and recovery. They run without model inference or a real account.
They do not measure model accuracy or verify an installation on a Mac.
