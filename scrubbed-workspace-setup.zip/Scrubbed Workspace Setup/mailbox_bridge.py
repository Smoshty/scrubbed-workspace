#!/usr/bin/env python3
"""Opt-in synthetic provider boundary around the normal checked-outbox pipeline."""
import argparse
import fcntl
import os
import hashlib
import json
from pathlib import Path
import secrets
import time
import sqlite3
from contextlib import closing

import mail_pipeline as p
import sanitizer
from synthetic_mailbox import Client, BoundaryError, MailboxUnavailable, token, unpack, validate_identity, validate_context


def sha(raw):return hashlib.sha256(raw).hexdigest()


def stored_status(root,identity):
    root=Path(root).absolute()
    if not root.resolve().is_relative_to(p.ROOT) or any(x.is_symlink() for x in [root,*root.parents] if x.is_relative_to(p.ROOT)):raise BoundaryError('invalid_status_root')
    marker=root/'scope.json';path=root/'state.sqlite3'
    if marker.is_symlink() or path.is_symlink():raise BoundaryError('invalid_status_storage')
    value=json.loads(marker.read_text())
    if value.get('scope')!='synthetic' or value.get('schema')!=1:raise BoundaryError('synthetic_scope_required')
    with closing(sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)) as db:
        db.row_factory=sqlite3.Row
        if json.loads(db.execute('SELECT identity FROM binding').fetchone()[0])!=validate_identity(identity):raise BoundaryError('account_binding_changed')
        states={r[0]:r[1] for r in db.execute('SELECT state,count(*) FROM jobs GROUP BY state')}
        health=(dict(db.execute('SELECT state,reason,failures,next_attempt FROM connection WHERE singleton=1').fetchone()) if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='connection'").fetchone() else dict(state='unverified',reason=None,failures=0,next_attempt=0))
        return dict(scope='synthetic-provider',jobs=sum(states.values()),arrivals=db.execute('SELECT count(*) FROM arrivals').fetchone()[0],states=states,
            exceptions={r[0]:r[1] for r in db.execute("SELECT reason,count(*) FROM jobs WHERE state IN ('held','retry','waiting') GROUP BY reason")},
            next_model_retry_at=db.execute("SELECT min(next_attempt) FROM jobs WHERE state IN ('retry','waiting') AND reason='model_unavailable'").fetchone()[0],
            transport={r[0]:r[1] for r in db.execute('SELECT state,count(*) FROM delivery GROUP BY state')},
            transport_exceptions={r[0]:r[1] for r in db.execute("SELECT reason,count(*) FROM delivery WHERE state IN ('uncertain','blocked') GROUP BY reason")},
            next_delivery_retry_at=db.execute("SELECT min(next_attempt) FROM delivery WHERE state='uncertain'").fetchone()[0],
            discovery_cursor=db.execute('SELECT cursor FROM binding').fetchone()[0],connection=health)


class Bridge(p.Pipeline):
    provider_mode=True
    def __init__(self,root,processor,fingerprint,client,identity,clock=time.time,crash_hook=None,page_size=2,check_online=True,workspace=False):
        self.identity=dict(validate_identity(identity));self.client=client;self.page_size=page_size
        self.workspace=workspace
        if workspace:
            from workspace_view import reader_root
            reader_root(root)
        if check_online and self.client.identify()!=self.identity:raise BoundaryError('account_binding_mismatch')
        self.client.identity=dict(self.identity)
        super().__init__(root,processor,fingerprint,clock,crash_hook)
        with self.locked(),p.database(self.path) as db:
            db.execute('CREATE TABLE IF NOT EXISTS binding(singleton INTEGER PRIMARY KEY CHECK(singleton=1),identity TEXT,cursor INTEGER NOT NULL DEFAULT 0)')
            old=db.execute('SELECT identity FROM binding').fetchone()
            encoded=json.dumps(self.identity,sort_keys=True)
            if old and old[0]!=encoded:raise BoundaryError('account_binding_changed')
            if not old and db.execute('SELECT count(*) FROM jobs').fetchone()[0]:raise BoundaryError('fresh_provider_root_required')
            db.execute('INSERT OR IGNORE INTO binding(singleton,identity) VALUES(1,?)',(encoded,))
            db.execute('CREATE TABLE IF NOT EXISTS sources(job_id TEXT PRIMARY KEY,provider_id TEXT UNIQUE,content_hash TEXT,thread_key TEXT,sender_key TEXT,context TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS contexts(kind TEXT,key TEXT,ref TEXT UNIQUE,PRIMARY KEY(kind,key))')
            db.execute('CREATE TABLE IF NOT EXISTS delivery(job_id TEXT PRIMARY KEY,key TEXT UNIQUE,output_hash TEXT,context TEXT,state TEXT,reason TEXT,next_attempt REAL DEFAULT 0,attempts INTEGER DEFAULT 0,receipt TEXT)')
            db.execute("CREATE TABLE IF NOT EXISTS connection(singleton INTEGER PRIMARY KEY CHECK(singleton=1),state TEXT,reason TEXT,failures INTEGER,next_attempt REAL)")
            db.execute("INSERT OR IGNORE INTO connection VALUES(1,'unverified',NULL,0,0)")
    def connection_state(self,state,reason=None):
        with p.database(self.path) as db:
            row=db.execute('SELECT failures FROM connection WHERE singleton=1').fetchone()
            failures=row[0]+1 if state=='waiting' else 0
            due=self.clock()+p.retry_delay(failures) if state=='waiting' else 0
            db.execute('UPDATE connection SET state=?,reason=?,failures=?,next_attempt=? WHERE singleton=1',(state,reason,failures,due))
    def run_once(self):
        # Serialize every bridge worker through delivery and reader publication.
        # The pipeline's inner lock ends before refresh; it is not sufficient here.
        lock=self.root/'.bridge.lock'
        if lock.is_symlink():raise ValueError('Invalid bridge lock')
        fd=os.open(lock,os.O_CREAT|os.O_RDWR,0o600)
        try:
            try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError as error:raise ValueError('Another worker is already running') from error
            return self._run_once()
        finally:os.close(fd)
    def _run_once(self):
        with p.database(self.path) as db:health=dict(db.execute('SELECT * FROM connection WHERE singleton=1').fetchone())
        if health['state']=='waiting' and self.clock()<health['next_attempt']:
            if self.workspace:
                from workspace_view import stale
                stale(self.root,'mailbox_unavailable')
            return self.status()
        self._provider_unavailable=False;self._provider_blocked=False
        try:
            if self.client.identify()!=self.identity:raise BoundaryError('account_binding_mismatch')
            super().run_once()
            if self._provider_blocked:raise BoundaryError('provider_response_invalid')
            self.connection_state('waiting','mailbox_unavailable') if self._provider_unavailable else self.connection_state('connected')
        except MailboxUnavailable:self.connection_state('waiting','mailbox_unavailable')
        except BoundaryError:
            self.connection_state('blocked','provider_response_invalid')
            if self.workspace:
                from workspace_view import stale
                stale(self.root,'provider_response_invalid')
            raise
        if self.workspace:
            from workspace_view import refresh,stale
            with p.database(self.path) as db:connected=db.execute('SELECT state FROM connection WHERE singleton=1').fetchone()[0]=='connected'
            refresh(self.root,self.client,self.identity,self.clock) if connected else stale(self.root,'mailbox_unavailable')
        return self.status()
    def reference(self,db,kind,key):
        db.execute('INSERT OR IGNORE INTO contexts VALUES(?,?,?)',(kind,key,secrets.token_hex(16)))
        return db.execute('SELECT ref FROM contexts WHERE kind=? AND key=?',(kind,key)).fetchone()[0]
    def scan(self):
        with p.database(self.path) as db:cursor=db.execute('SELECT cursor FROM binding').fetchone()[0]
        page=self.client.page(cursor,self.page_size)
        if not isinstance(page,dict) or set(page)!={'items','cursor'} or not isinstance(page['items'],list) or len(page['items'])>self.page_size:raise BoundaryError('invalid_page')
        captured=[];last=cursor
        for item in page['items']:
            if not isinstance(item,dict) or set(item)!={'id','seq','thread','sender','raw'}:raise BoundaryError('invalid_source_record')
            for name in ['id','thread','sender']:token(item[name])
            if type(item['seq']) is not int or item['seq']<=last:raise BoundaryError('invalid_cursor_order')
            last=item['seq'];raw=unpack(item['raw'])
            if len(raw)>2*1024*1024:raise BoundaryError('message_transport_limit')
            ident=sha(json.dumps([self.identity['source'],item['id']],separators=(',',':')).encode())
            captured.append((ident,item,raw,sha(raw)))
        if type(page['cursor']) is not int or page['cursor']!=last:raise BoundaryError('invalid_page_cursor')
        with p.database(self.path) as db:
            for ident,item,raw,digest in captured:
                old=db.execute('SELECT * FROM sources WHERE provider_id=?',(item['id'],)).fetchone()
                if old and (old['content_hash'],old['thread_key'],old['sender_key'])!=(digest,item['thread'],item['sender']):raise BoundaryError('source_identity_conflict')
                if old:continue
                ref=secrets.token_hex(16)
                conversation=self.reference(db,'conversation',item['thread'])
                sender=self.reference(db,'sender',json.dumps([item['thread'],item['sender']]))
                context=dict(message_ref=ref,conversation_ref=conversation,sender_ref=sender,alias_scope='per-message',sender_scope='reported-participant-in-conversation')
                oversized=len(raw)>sanitizer.screener.MAX_BYTES
                db.execute('INSERT INTO jobs(id,reference,original,state,reason) VALUES(?,?,?,?,?)',(ident,ref,raw,'held' if oversized else 'queued','message_too_large' if oversized else None))
                db.execute('INSERT INTO sources VALUES(?,?,?,?,?,?)',(ident,item['id'],digest,item['thread'],item['sender'],json.dumps(context,sort_keys=True)))
                db.execute('INSERT INTO arrivals VALUES(?,?)',(item['id'],ident));self.event(db,ident,'provider_captured')
            self.crash_hook('before_cursor_commit',dict(cursor=last))
            db.execute('UPDATE binding SET cursor=?',(last,))
        self.crash_hook('after_cursor_commit',dict(cursor=last))
        return 0
    def defer(self,ident,reason):
        with p.database(self.path) as db:
            db.execute("UPDATE delivery SET state='uncertain',reason=?,next_attempt=? WHERE job_id=?",(reason,self.clock()+10,ident))
    def publish(self,job):
        if getattr(self,'_provider_unavailable',False) or getattr(self,'_provider_blocked',False):return
        raw=job['clean']
        if raw is None or sha(raw)!=job['output_sha256']:raise sanitizer.Hold('stored_output_corrupt')
        with p.database(self.path) as db:
            entry=db.execute('SELECT * FROM delivery WHERE job_id=?',(job['id'],)).fetchone()
            source=db.execute('SELECT context FROM sources WHERE job_id=?',(job['id'],)).fetchone()
            if not source:raise sanitizer.Hold('source_binding_missing')
            context=validate_context(json.loads(source['context']))
            if context['message_ref']!=job['reference']:raise sanitizer.Hold('context_binding_corrupt')
            if job['fingerprint']!=self.fingerprint:
                if entry:raise sanitizer.Hold('inflight_configuration_changed')
                db.execute("UPDATE jobs SET state='retry',reason='configuration_changed',clean=NULL,output_sha256=NULL,mapping=NULL,audit=NULL,next_attempt=0 WHERE id=?",(job['id'],))
                return
            key=sha(json.dumps([self.identity['service_id'],self.identity['destination'],job['reference']],separators=(',',':')).encode())
            if not entry:
                db.execute("INSERT INTO delivery(job_id,key,output_hash,context,state) VALUES(?,?,?,?,'pending')",(job['id'],key,sha(raw),json.dumps(context,sort_keys=True)))
                entry=db.execute('SELECT * FROM delivery WHERE job_id=?',(job['id'],)).fetchone()
            entry=dict(entry)
        if entry['key']!=key or entry['output_hash']!=sha(raw) or entry['context']!=json.dumps(context,sort_keys=True):raise sanitizer.Hold('delivery_binding_corrupt')
        if entry['state'] not in {'pending','uncertain','blocked','confirmed'}:raise sanitizer.Hold('invalid_delivery_state')
        if entry['state']=='blocked':raise sanitizer.Hold(entry['reason'])
        if entry['state']=='confirmed':raise sanitizer.Hold('delivery_state_conflict')
        if self.clock()<entry['next_attempt']:return
        # Always reconcile before sending, including after any lost response/crash.
        try:receipt=self.client.lookup(entry['key'])
        except MailboxUnavailable:
            self._provider_unavailable=True;self.defer(job['id'],'reconciliation_unavailable');return
        except BoundaryError:
            self._provider_blocked=True;raise sanitizer.Hold('provider_response_invalid')
        if not isinstance(receipt,dict) or set(receipt)!={'authoritative','items'} or type(receipt['authoritative']) is not bool or not isinstance(receipt['items'],list):
            self._provider_blocked=True;raise sanitizer.Hold('provider_response_invalid')
        if not receipt['authoritative']:
            self.defer(job['id'],'reconciliation_unknown');return
        if receipt['items']:
            try:
                if len(receipt['items'])!=1:raise BoundaryError('duplicate_destination_matches')
                match=receipt['items'][0]
                if set(match)!={'id','raw','context'} or unpack(match['raw'])!=raw or match['context']!=context:raise BoundaryError('destination_content_conflict')
                token(match['id'])
            except (BoundaryError,KeyError,TypeError):
                with p.database(self.path) as db:db.execute("UPDATE delivery SET state='blocked',reason='destination_reconciliation_conflict' WHERE job_id=?",(job['id'],))
                raise sanitizer.Hold('destination_reconciliation_conflict')
            with p.database(self.path) as db:
                db.execute("UPDATE delivery SET state='confirmed',reason='exact_destination_match',receipt=? WHERE job_id=?",(match['id'],job['id']))
                db.execute("UPDATE jobs SET state='delivered',reason='verified_simulated_inbox',updated_at=CURRENT_TIMESTAMP WHERE id=?",(job['id'],));self.event(db,job['id'],'destination_confirmed')
            (self.root/'exceptions'/(job['reference']+'.json')).unlink(missing_ok=True)
            return
        # This fake service guarantees authoritative absence. Real provider APIs
        # require their own proven reconciliation contract; this is not portable.
        with p.database(self.path) as db:db.execute("UPDATE delivery SET state='uncertain',reason='submission_started',attempts=attempts+1,next_attempt=? WHERE job_id=?",(self.clock()+10,job['id']))
        self.crash_hook('before_submit',job)
        try:self.client.submit(entry['key'],raw,context)
        except MailboxUnavailable:
            self._provider_unavailable=True;self.defer(job['id'],'submission_unacknowledged');return
        except BoundaryError:
            self._provider_blocked=True;raise sanitizer.Hold('provider_response_invalid')
        self.crash_hook('after_submit',job)
        # A positive acknowledgement also requires a later readback of exact bytes.
        with p.database(self.path) as db:db.execute('UPDATE delivery SET next_attempt=0 WHERE job_id=?',(job['id'],))
    def status(self):
        value=stored_status(self.root,self.identity)
        if self.workspace:
            from workspace_view import status
            value['reader']=status(self.root)
        return value


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--endpoint');parser.add_argument('--binding',required=True,type=Path)
    parser.add_argument('command',choices=['run','watch','status','exceptions']);parser.add_argument('--poll',type=float,default=1)
    parser.add_argument('--sender-context',action='store_true')
    parser.add_argument('--workspace',action='store_true',help='Explicit sender-context candidate with automatic checked reader refresh')
    args=parser.parse_args()
    identity=validate_identity(json.loads(args.binding.read_text()))
    if args.command=='exceptions':
        from workspace_view import exceptions
        print(json.dumps(exceptions(args.root,identity)));return
    if args.command=='status':
        value=stored_status(args.root,identity)
        if args.workspace:
            from workspace_view import status
            value['reader']=status(args.root)
        print(json.dumps(value));return
    if not args.endpoint:parser.error('--endpoint is required for processing')
    client=Client(args.endpoint,identity)
    if args.command in {'run','watch'}:
        import sender_sanitizer
        processor,fingerprint=p.production_processor(sanitizer.MODEL,sanitizer_module=sender_sanitizer if args.sender_context or args.workspace else None)
    bridge=Bridge(args.root,processor,fingerprint,client,identity,check_online=False,workspace=args.workspace)
    previous=None
    while True:
        value=bridge.status() if args.command=='status' else bridge.run_once()
        current=json.dumps(value,sort_keys=True)
        if current!=previous:print(current,flush=True);previous=current
        if args.command!='watch':break
        time.sleep(max(.1,args.poll))


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:pass
    except BoundaryError as error:raise SystemExit(str(error))
