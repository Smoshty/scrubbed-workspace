"""Verify the local bridge with bundled fictional email, including a later arrival."""

import base64
from contextlib import closing, contextmanager
from email import policy
from email.parser import BytesParser
import hashlib
import html
import json
from pathlib import Path
import re
import signal
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from benchmark.run import catalog, listening
from flow.verify_recovery import stop_worker, wait_for
from mail_pipeline import atomic_file
from sanitizer import MODEL, literal_matches
from synthetic_mailbox import BoundaryError, Client, unpack

INITIAL_CASES = ('care-quoted', 'unsupported')
FOLLOWUP = 'later-arrival'
CASES = (*INITIAL_CASES, FOLLOWUP)
MODEL_DIGEST = '56671c2ab9385f9cfcb404638e32cd62d88e3501d44822208363c010179a3c90'


def require(condition, description):
    if not condition:
        raise RuntimeError(description)


@contextmanager
def process(argv, log):
    with log.open('wb') as stream:
        child = subprocess.Popen(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                 start_new_session=True)
    try:
        yield child
    finally:
        stop_worker(child)


def invoke(argv):
    return subprocess.run(argv, cwd=ROOT, capture_output=True, check=True, timeout=30)


def rows(path, table):
    if not path.is_file():
        return []
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        try:
            return [dict(row) for row in db.execute(f'SELECT * FROM {table}')]
        except sqlite3.OperationalError as error:
            if str(error).startswith('no such table:'):
                return []
            raise


def parser(raw):
    return BytesParser(policy=policy.default).parsebytes(raw)


def progress(message):
    print(message, flush=True)


def owner_status(stage):
    invoke(['./handoff/demo/owner-status', stage])


def run(folder):
    if listening():
        owner_status('busy')
        raise RuntimeError('Another local checker is already using the demo port.')
    fixture_path = ROOT / 'flow/workspace-cases-v1.json'
    cases = {case['id']: case for case in json.loads(fixture_path.read_text())['cases']
             if case['id'] in CASES}
    originals = {key: (ROOT / cases[key]['eml_file']).read_bytes() for key in CASES}
    (folder / 'inputs.json').write_text(json.dumps({
        'cases': cases,
        'source_sha256': {key: hashlib.sha256(raw).hexdigest() for key, raw in originals.items()},
    }, indent=2) + '\n')
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    client = Client(f'http://127.0.0.1:{port}')
    provider_root = folder / 'practice-mailbox'
    bridge_root = folder / 'bridge'
    bridge = bridge_root / 'state.sqlite3'
    provider = provider_root / 'service.sqlite3'
    reader = folder / 'bridge-reader' / 'current.json'
    binding = folder / 'binding.json'
    bridge_args = [sys.executable, 'mailbox_bridge.py', '--root', str(bridge_root), '--binding',
                   str(binding), '--endpoint', client.endpoint, '--workspace']

    def available():
        try:
            return client.identify()['scope'] == 'synthetic-mailbox'
        except BoundaryError:
            return False

    def seed(key):
        entry = cases[key]
        client.seed(key, entry['thread'], entry['sender'], originals[key])

    def reader_call(tool='list_messages', arguments=None):
        return json.loads(invoke([sys.executable, 'filtered_inbox.py', 'read', '--snapshot',
                                  str(reader.parent), '--tool', tool, '--arguments',
                                  json.dumps(arguments or {})]).stdout)

    def check_hidden(tool, arguments):
        try:
            reader_call(tool, arguments)
        except subprocess.CalledProcessError as error:
            require(not error.stdout.strip(), 'The reader unexpectedly returned information.')
            return
        raise RuntimeError(f'The reader accepted {tool} for a hidden message.')

    provider_args = [sys.executable, 'synthetic_mailbox.py', '--root', str(provider_root),
                     '--port', str(port), '--source', 'practice-originals', '--destination',
                     'practice-checked', '--drop-first-ack']
    watch_args = bridge_args + ['watch', '--poll', '.3']
    with process(provider_args, folder / 'mailbox.log') as service:
        wait_for(available, service, 'practice mailbox', 15)
        client.identity = client.identify()
        binding.write_text(json.dumps(client.identity))
        for key in INITIAL_CASES:
            seed(key)
        require({row['id']: row['raw'] for row in rows(provider, 'source')}
                == {key: originals[key] for key in INITIAL_CASES},
                'The practice inbox did not accept the exact samples.')
        owner_status('checking')
        progress('The first two fictional emails are ready. The local checker is starting.')
        with process(['./handoff/demo/model-server', 'serve'], folder / 'checker.log') as model:
            wait_for(listening, model, 'local checker', 25)
            require(any(entry['name'] == MODEL and entry['digest'] == MODEL_DIGEST
                        for entry in catalog()), 'The tested demo model is missing or has changed.')
            progress('The computer is checking the emails. This usually takes a minute or two.')
            with process(watch_args, folder / 'worker-first.log') as worker:
                wait_for(lambda: any(row['reason'] == 'submission_unacknowledged'
                                     for row in rows(bridge, 'delivery')),
                         worker, 'first checked copy', 300)
            require(len(rows(provider, 'destination')) == 1
                    and (not reader.is_file() or not reader_call()['messages']),
                    'A copy became visible before the inbox confirmed it.')
            owner_status('restarting')
            progress('A copy was saved but receipt was unconfirmed. Restarting to check for duplicates.')

            def recovered():
                return (reader.is_file()
                        and {row['state'] for row in rows(bridge, 'jobs')} == {'delivered', 'held'}
                        and len(reader_call()['messages']) == 1)

            with process(watch_args, folder / 'worker-restarted.log') as worker:
                wait_for(recovered, worker, 'confirmed copy and held attachment', 45)
                first_copy = rows(provider, 'destination')
                require(len(first_copy) == 1,
                        'Restart left more than one copy of the first email.')
                owner_status('followup')
                progress('Restart worked. Checking whether a new fictional email arrives on its own.')
                seed(FOLLOWUP)
                wait_for(lambda: len(reader_call()['messages']) == 2, worker,
                         'new checked copy in the practice reader', 300)

        jobs = {job['id']: job for job in rows(bridge, 'jobs')}
        arrival = {row['provider_id']: jobs[row['job_id']] for row in rows(bridge, 'sources')}
        held = arrival['unsupported']
        report = json.loads(invoke(bridge_args + ['exceptions']).stdout)
        require(not report['waiting'] and not report['delivery']
                and [(item['reference'], item['reason']) for item in report['held']]
                == [(held['reference'], 'uninspected_attachment')],
                'The local hold report does not explain the image hold.')
        deliveries = {row['job_id']: row for row in rows(bridge, 'delivery')}
        destination = rows(provider, 'destination')
        require(len(deliveries) == len(destination) == 2 and first_copy[0] in destination,
                'The new arrival did not leave two copies with the first copy intact.')

        def verify_copy(key):
            job = arrival[key]
            delivery = deliveries[job['id']]
            require(job['state'] == 'delivered' and delivery['state'] == 'confirmed'
                    and delivery['attempts'] == 1, f'{key}: expected one confirmed submission.')
            receipt = client.lookup(delivery['key'])
            require(receipt['authoritative'] and len(receipt['items']) == 1,
                    f'{key}: the practice inbox did not return one authoritative copy.')
            raw = unpack(receipt['items'][0]['raw'])
            require(raw == job['clean'] and sum(row['raw'] == raw for row in destination) == 1
                    and hashlib.sha256(raw).hexdigest() == job['output_sha256'],
                    f'{key}: the read-back bytes differ from the checked copy.')
            checked = parser(raw)
            result = reader_call('read_message', {'reference': job['reference']})['messages'][0]
            require(set(result) == {'subject', 'body', 'context', 'reference'}
                    and result['subject'] == str(checked['Subject'])
                    and result['body'] == checked.get_content().replace('\r\n', '\n'),
                    f'{key}: the separate reader does not match the checked copy.')
            decoded = '\n'.join(str(value) for _, value in checked.items()) + '\n' + result['body']
            require(all(value in decoded for value in cases[key]['keep'])
                    and not any(literal_matches(value, decoded) for value in cases[key]['forbidden']),
                    f'{key}: the copy lost a required task or kept an invented identifier.')
            return raw, result

        checked_raw, result = verify_copy('care-quoted')
        _, followup = verify_copy(FOLLOWUP)
        require(held['state'] == 'held' and held['reason'] == 'uninspected_attachment',
                'The image was not held for the expected reason.')
        check_hidden('read_message', {'reference': held['reference']})
        check_hidden('read_original', {'reference': arrival['care-quoted']['reference']})
        for key in ('care-quoted', FOLLOWUP):
            seed(key)
        invoke(bridge_args + ['run'])
        require(rows(provider, 'destination') == destination and rows(bridge, 'jobs') == list(jobs.values()),
                'Replay created another copy or reprocessed an existing message.')
        require({row['id']: row['raw'] for row in rows(provider, 'source')} == originals
                and all(arrival[key]['original'] == originals[key] for key in CASES),
                'An original message changed during the demo.')
    require(not listening(), 'The practice checker is still running.')
    require(len(reader_call()['messages']) == 2, 'The checked copies could not be reopened offline.')
    return (originals['care-quoted'], checked_raw, result, followup,
            str(parser(originals['unsupported'])['Subject']), cases['care-quoted']['forbidden'])


def highlight(text, pattern, css_class):
    segments = re.split(f'({pattern})', text)
    return ''.join(f'<mark class="{css_class}">{html.escape(segment)}</mark>'
                   if index % 2 else html.escape(segment)
                   for index, segment in enumerate(segments))


def results_page(original_raw, checked_raw, readback, followup, held_subject, forbidden):
    esc = html.escape
    original, checked = parser(original_raw), parser(checked_raw)
    template = (ROOT / 'handoff/demo/report.html').read_text()
    planted = '|'.join(re.escape(value) for value in forbidden)
    aliases = r'\[(?:PERSON|ID)_\d+\]'
    replacements = {
        'ORIGINAL_SUBJECT': highlight(str(original['Subject']), planted, 'removal'),
        'ORIGINAL_BODY': highlight(original.get_content().strip(), planted, 'removal'),
        'CHECKED_SUBJECT': highlight(str(checked['Subject']), aliases, 'replacement'),
        'CHECKED_BODY': highlight(readback['body'].strip(), aliases, 'replacement'),
        'FOLLOWUP_SUBJECT': esc(followup['subject']),
        'FOLLOWUP_BODY': esc(followup['body'].strip()),
        'HELD_SUBJECT': esc(held_subject),
        'RUN_DATE': esc(time.strftime('%B %d, %Y at %H:%M')),
        'ORIGINAL_FILE': base64.b64encode(original_raw).decode('ascii'),
        'CHECKED_FILE': base64.b64encode(checked_raw).decode('ascii'),
    }
    for name, value in replacements.items():
        template = template.replace('@@' + name + '@@', value)
    return template.encode()


def interrupt(signum, frame):
    raise KeyboardInterrupt


def main():
    signal.signal(signal.SIGTERM, interrupt)
    output = ROOT / 'data/practice-demo'
    folder = Path(tempfile.mkdtemp(prefix='run-', dir=output))
    started = time.monotonic()
    try:
        proof = run(folder)
        destination = folder / 'Results.html'
        atomic_file(destination, results_page(*proof))
        atomic_file(output / 'latest.txt', (str(destination) + '\n').encode())
        (output / 'last-failure.txt').unlink(missing_ok=True)
    except (Exception, KeyboardInterrupt) as error:
        (folder / 'failure.txt').write_text(repr(error) + '\n')
        atomic_file(output / 'last-failure.txt', (str(folder) + '\n').encode())
        progress('The demo stopped before all checks passed. No new results page was published.')
        progress('The setup agent can inspect this attempt at ' + str(folder))
        return 1
    progress(f'Finished in {round(time.monotonic() - started)} seconds. The demo is stopped.')
    progress('Open the results: ' + str(destination))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
