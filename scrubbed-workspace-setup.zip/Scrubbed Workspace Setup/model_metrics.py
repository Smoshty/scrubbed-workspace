"""Source-free inference timings. Missing/invalid metrics remain missing."""
DURATIONS={'total_duration':'server_seconds','load_duration':'load_seconds',
           'prompt_eval_duration':'prompt_seconds','eval_duration':'generation_seconds'}
COUNTS=('prompt_eval_count','prompt_eval_cached_count','eval_count')


def record(envelope,elapsed,stage,success):
    result={'stage':stage if stage in {'plan','check'} else 'unknown',
            'wall_seconds':round(elapsed,6),'completed_json_response':bool(success)}
    if not isinstance(envelope,dict):return result
    for source,target in DURATIONS.items():
        value=envelope.get(source)
        if type(value) is int and 0<=value<=2**63-1:result[target]=value/1_000_000_000
    for source in COUNTS:
        value=envelope.get(source)
        if type(value) is int and 0<=value<=2**63-1:result[source]=value
    reason=envelope.get('done_reason')
    result['finish_reason']=reason if reason in ('stop','length') else 'other'
    return result
