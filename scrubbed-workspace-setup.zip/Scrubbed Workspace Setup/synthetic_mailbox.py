#!/usr/bin/env python3
"""Local fake mailbox HTTP service. No credentials, real accounts or mail delivery."""
import argparse
import hashlib
import base64
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import http.client
from pathlib import Path
import re
import secrets
import sqlite3
from urllib.error import URLError, HTTPError
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler

from mail_pipeline import ROOT, atomic_file, database

MAX_FRAME=16*1024*1024


class BoundaryError(Exception):pass


class MailboxUnavailable(BoundaryError):pass


def binding_hash(identity):return hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()


def token(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',value):
        raise BoundaryError('invalid_provider_identifier')
    return value


def unpack(value):
    try:return base64.b64decode(value,validate=True)
    except (ValueError,TypeError):raise BoundaryError('invalid_message_encoding')


def packed(raw):return base64.b64encode(raw).decode('ascii')


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise BoundaryError('redirect_forbidden')


class Client:
    """A bounded localhost-only test client; proxy environment variables are ignored."""
    def __init__(self,endpoint,identity=None):
        parsed=urlparse(endpoint)
        if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or not parsed.port or parsed.path not in {'','/'} or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise BoundaryError('localhost_simulator_required')
        self.endpoint=endpoint.rstrip('/');self.identity=dict(identity) if identity is not None else None
        self.opener=build_opener(ProxyHandler({}),NoRedirect())
    def request(self,path,value=None):
        headers={'Content-Type':'application/json'}
        if self.identity:headers['X-Synthetic-Binding']=binding_hash(self.identity)
        request=Request(self.endpoint+path,data=None if value is None else json.dumps(value).encode(),headers=headers)
        try:
            with self.opener.open(request,timeout=5) as response:
                if self.identity and response.headers.get('X-Synthetic-Service-ID')!=self.identity['service_id']:raise BoundaryError('service_identity_changed')
                raw=response.read(MAX_FRAME+1)
                if len(raw)>MAX_FRAME:raise BoundaryError('response_too_large')
                return json.loads(raw)
        except HTTPError as e:
            if e.code in {429,502,503,504}:raise MailboxUnavailable('mailbox_unavailable') from e
            raise BoundaryError('provider_http_error') from e
        except (URLError,OSError,http.client.IncompleteRead) as e:raise MailboxUnavailable('mailbox_unavailable') from e
        except (ValueError,http.client.HTTPException) as e:raise BoundaryError('invalid_provider_response') from e
    def identify(self):return self.request('/identity')
    def page(self,cursor,limit):return self.request(f'/source?after={cursor}&limit={limit}')
    def seed(self,ident,thread,sender,raw):return self.request('/source',dict(id=ident,thread=thread,sender=sender,raw=packed(raw)))
    def lookup(self,key):return self.request('/destination?key='+token(key))
    def submit(self,key,raw,context):return self.request('/destination',dict(key=key,raw=packed(raw),context=context))


def validate_identity(value):
    if not isinstance(value,dict) or set(value)!={'scope','schema','service_id','source','destination'} or value['scope']!='synthetic-mailbox' or value['schema']!=1:
        raise BoundaryError('synthetic_identity_required')
    for name in ['service_id','source','destination']:token(value[name])
    if not re.fullmatch('[a-f0-9]{32}',value['service_id']) or value['source']==value['destination']:
        raise BoundaryError('distinct_account_binding_required')
    return value


def validate_context(value):
    keys={'message_ref','conversation_ref','sender_ref','alias_scope','sender_scope'}
    if not isinstance(value,dict) or set(value)!=keys:raise BoundaryError('invalid_context')
    if value['alias_scope']!='per-message' or value['sender_scope']!='reported-participant-in-conversation':raise BoundaryError('invalid_context')
    for name in ['message_ref','conversation_ref','sender_ref']:
        if not isinstance(value[name],str) or not re.fullmatch('[a-f0-9]{32}',value[name]):raise BoundaryError('invalid_context')
    return value


def serve(root,port,source,destination,drop_first_ack=False):
    root=Path(root).absolute()
    if root.is_symlink() or not root.resolve().is_relative_to(ROOT/'data'):raise BoundaryError('project_data_root_required')
    root.mkdir(parents=True,exist_ok=True,mode=0o700)
    marker=root/'identity.json';path=root/'service.sqlite3'
    if marker.is_symlink() or path.is_symlink():raise BoundaryError('unsafe_service_path')
    if marker.exists():
        identity=validate_identity(json.loads(marker.read_text()))
        if (identity['source'],identity['destination'])!=(source,destination):raise BoundaryError('service_account_change')
    else:
        if any(root.iterdir()):raise BoundaryError('unmarked_service_root')
        identity=validate_identity(dict(scope='synthetic-mailbox',schema=1,service_id=secrets.token_hex(16),source=source,destination=destination))
        atomic_file(marker,(json.dumps(identity)+'\n').encode())
    with database(path) as db:
        db.execute('CREATE TABLE IF NOT EXISTS source(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE,thread TEXT,sender TEXT,raw BLOB)')
        # Deliberately no unique key: blind resend would create a second copy.
        db.execute('CREATE TABLE IF NOT EXISTS destination(id TEXT PRIMARY KEY,key TEXT,raw BLOB,context TEXT)')
    faults={'drop_ack':drop_first_ack}
    class Handler(BaseHTTPRequestHandler):
        def setup(self):super().setup();self.connection.settimeout(5)
        def log_message(self,*args):pass
        def reply(self,value,status=200):
            raw=json.dumps(value).encode();self.send_response(status)
            self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)))
            self.send_header('X-Synthetic-Service-ID',identity['service_id']);self.end_headers();self.wfile.write(raw)
        def do_GET(self):
            try:
                u=urlparse(self.path);q=parse_qs(u.query)
                if (u.path!='/identity' or self.headers.get('X-Synthetic-Binding')) and self.headers.get('X-Synthetic-Binding')!=binding_hash(identity):
                    self.close_connection=True;return self.reply(dict(error='binding_mismatch'),409)
                if u.path=='/identity':return self.reply(identity)
                with database(path) as db:
                    if u.path=='/source':
                        after=int(q.get('after',['0'])[0]);limit=int(q.get('limit',['2'])[0])
                        if after<0 or not 1<=limit<=10:raise BoundaryError('invalid_page')
                        rows=db.execute('SELECT * FROM source WHERE seq>? ORDER BY seq LIMIT ?',(after,limit)).fetchall()
                        return self.reply(dict(items=[dict(seq=r['seq'],id=r['id'],thread=r['thread'],sender=r['sender'],raw=packed(r['raw'])) for r in rows],cursor=rows[-1]['seq'] if rows else after))
                    if u.path=='/destination':
                        key=token(q['key'][0]);rows=db.execute('SELECT * FROM destination WHERE key=?',(key,)).fetchall()
                        return self.reply(dict(authoritative=True,items=[dict(id=r['id'],raw=packed(r['raw']),context=json.loads(r['context'])) for r in rows]))
                raise BoundaryError('unknown_endpoint')
            except (BoundaryError,ValueError,KeyError):self.reply(dict(error='invalid_request'),400)
        def do_POST(self):
            try:
                if self.headers.get('X-Synthetic-Binding')!=binding_hash(identity):
                    self.close_connection=True;return self.reply(dict(error='binding_mismatch'),409)
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=MAX_FRAME:raise BoundaryError('invalid_length')
                value=json.loads(self.rfile.read(length))
                raw=unpack(value['raw'])
                if len(raw)>2*1024*1024:raise BoundaryError('message_transport_limit')
                if self.path=='/source':
                    if set(value)!={'id','thread','sender','raw'}:raise BoundaryError('invalid_source')
                    for name in ['id','thread','sender']:token(value[name])
                    with database(path) as db:
                        old=db.execute('SELECT * FROM source WHERE id=?',(value['id'],)).fetchone()
                        if old and (old['thread'],old['sender'],old['raw'])!=(value['thread'],value['sender'],raw):raise BoundaryError('immutable_source_conflict')
                        db.execute('INSERT OR IGNORE INTO source(id,thread,sender,raw) VALUES(?,?,?,?)',(value['id'],value['thread'],value['sender'],raw))
                    return self.reply(dict(accepted=True))
                if self.path=='/destination':
                    if set(value)!={'key','raw','context'}:raise BoundaryError('invalid_submission')
                    token(value['key']);validate_context(value['context'])
                    ident=secrets.token_hex(16)
                    with database(path) as db:db.execute('INSERT INTO destination VALUES(?,?,?,?)',(ident,value['key'],raw,json.dumps(value['context'],sort_keys=True)))
                    if faults['drop_ack']:
                        faults['drop_ack']=False;self.close_connection=True;return
                    return self.reply(dict(accepted=True))
                raise BoundaryError('unknown_endpoint')
            except (BoundaryError,ValueError,KeyError,TypeError):self.reply(dict(error='invalid_request'),400)
    HTTPServer(('127.0.0.1',port),Handler).serve_forever()


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True,type=Path)
    p.add_argument('--port',required=True,type=int);p.add_argument('--source',required=True);p.add_argument('--destination',required=True)
    p.add_argument('--drop-first-ack',action='store_true');a=p.parse_args()
    serve(a.root,a.port,a.source,a.destination,a.drop_first_ack)


if __name__=='__main__':main()
