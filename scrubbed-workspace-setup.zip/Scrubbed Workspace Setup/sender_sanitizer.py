"""Opt-in display-name context, fully inspected by the focused sanitizer."""
from email import policy
from email.message import EmailMessage
from email.parser import BytesParser
import context_sanitizer as focused

SENDER_CONTEXT_NOTE='''
The reported sender line is an unverified display label, not proof of identity.
A generic unnamed staff/team/department label by itself, such as "Care team",
is not a uniquely identifying person clue. Names, contact details, unusual roles
and identifying stories still need discovery and checking, including on this line.
A generic team prefix does not exempt any name or identifying clue that follows.
Apply the ordinary role and ambiguity rules; this is not a label allowlist.
'''


class LocalModel(focused.LocalModel):
    def request(self,stage,system,payload,schema):
        return super().request(stage,system+'\n'+SENDER_CONTEXT_NOTE,payload,schema)

LocalDetector=focused.LocalDetector
Hold=focused.Hold
Retryable=focused.Retryable
DEPENDENCIES=('sanitizer.py','experimental_sanitizer.py','context_sanitizer.py')


def prepare(raw):
    # Complete inspection first: converting to text must not discard unsupported parts.
    source=focused.shared.extract(raw)
    parsed=BytesParser(policy=policy.default).parsebytes(raw)
    headers=parsed.get_all('From',[])
    if len(headers)!=1 or headers[0].defects:raise Hold('sender_header_ambiguous')
    addresses=headers[0].addresses
    if len(addresses)!=1:raise Hold('sender_header_ambiguous')
    name=addresses[0].display_name.strip() or 'Unnamed sender'
    if len(name)>256 or '\n' in name or '\r' in name:raise Hold('sender_label_limit')
    message=EmailMessage()
    try:
        for key,value in parsed.items():
            if key.lower()!='mime-version' and not key.lower().startswith('content-'):
                message[key]=str(value)
        message['X-Local-Source-Context']=source['source_headers'].replace('\r',' ').replace('\n',' | ')
        message.set_content('Reported sender (unverified): '+name+'\n\n'+source['body'])
    except ValueError as error:raise Hold('sender_header_ambiguous') from error
    return message.as_bytes()


def sanitize(raw,reference,detector,model):
    try:result=focused.sanitize(prepare(raw),reference,detector,model)
    except focused.shared.Retryable as error:raise Retryable(error.reason) from error
    except focused.shared.Hold as error:raise Hold(error.reason) from error
    result.audit['sender_context']='display-name-v1'
    result.audit['sender_discovery']='display-label-context-v2'
    return result
