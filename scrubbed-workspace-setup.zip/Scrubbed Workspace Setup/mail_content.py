"""Bounded, non-rendering extraction of plain text and a safe HTML subset."""
from email import policy
from email.header import decode_header
from email.parser import BytesParser
from html.parser import HTMLParser
import re
from urllib.parse import urlsplit
from pdf_text import extract_pdf, PDFError

class ContentError(Exception):
    pass

class TextHTML(HTMLParser):
    blocks={'p','div','br','hr','blockquote','ul','ol','li','table','tr','td','th','h1','h2','h3','h4','h5','h6','pre'}
    void={'br','hr','meta','wbr'}
    allowed=blocks|void|{'html','head','body','title','style','span','b','strong','em','i','u','s','small','big','font','a','code','thead','tbody','tfoot','center','section','article'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack=[];self.text=[];self.links=[];self.style=[]
    def gap(self):self.text.append('\n')
    def handle_decl(self,decl):
        if decl.lower() not in {'doctype html'}:raise ContentError('unsupported_html_declaration')
    def unknown_decl(self,data):raise ContentError('unsupported_html_declaration')
    def handle_pi(self,data):raise ContentError('unsupported_html_declaration')
    def handle_starttag(self,tag,attrs):
        if tag not in self.allowed:raise ContentError('unsupported_html_element')
        if len(self.stack)>=64:raise ContentError('html_nesting_limit')
        keys=[k for k,_ in attrs]
        if len(set(keys))!=len(keys):raise ContentError('ambiguous_html_attributes')
        attrs=dict(attrs)
        if any(k.startswith('on') for k in attrs):raise ContentError('active_html_content')
        if tag=='meta' and attrs.get('http-equiv','').lower()=='refresh':raise ContentError('active_html_content')
        if re.search(r'url\s*\(|expression\s*\(|content\s*:|@import',attrs.get('style') or '',re.I):raise ContentError('unsupported_html_style')
        if tag=='a':
            href=attrs.get('href') or ''
            if href:
                scheme=urlsplit(href).scheme.lower()
                if scheme not in {'http','https','mailto','tel'} and not href.startswith('#'):raise ContentError('unsupported_html_link')
            self.links.append((href,len(self.text)))
        if tag in self.blocks:self.gap()
        if tag not in self.void:self.stack.append(tag)
        # Preserve meaningful tooltip/accessibility text as text, never markup.
        if not any(t in {'head','title','style'} for t in self.stack):
            for key in ('title','aria-label'):
                if attrs.get(key):
                    self.gap();self.text.append(attrs[key]);self.gap()
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if tag not in self.void:self.handle_endtag(tag)
    def handle_endtag(self,tag):
        if tag in self.void:return
        if not self.stack or self.stack[-1]!=tag:raise ContentError('incomplete_or_ambiguous_html')
        self.stack.pop()
        if tag=='a':
            href,start=self.links.pop()
            visible=''.join(self.text[start:]).strip()
            if href and href!=visible:self.text.extend(['\nLink destination: ',href,'\n'])
        if tag in self.blocks:self.gap()
    def handle_data(self,data):
        if 'style' in self.stack:
            self.style.append(data);return
        if any(t in {'head','title'} for t in self.stack):return
        # Include body text even when CSS would hide it: no invisible text bypass.
        self.text.append(data)
    def result(self):
        if self.stack or self.links or self.rawdata:raise ContentError('incomplete_or_ambiguous_html')
        if re.search(r'url\s*\(|expression\s*\(|content\s*:|@import',''.join(self.style),re.I):raise ContentError('unsupported_html_style')
        text=''.join(self.text).replace('\r\n','\n')
        text=re.sub(r'[ \t\f\v]+',' ',text)
        text=re.sub(r' *\n *','\n',text)
        return re.sub(r'\n{3,}','\n\n',text).strip()


def html_to_text(source):
    parser=TextHTML()
    try:
        parser.feed(source)
        if parser.rawdata:raise ContentError('incomplete_or_ambiguous_html')
        parser.close()
        return parser.result()
    except ContentError:raise
    except Exception as e:raise ContentError('unreadable_html') from e


def extract_message(raw,max_bytes=128000):
    if len(raw)>max_bytes:raise ContentError('message_too_large')
    msg=BytesParser(policy=policy.default).parsebytes(raw)
    headers=[];formats=[];attachments=[0]
    def visit(part,attachment_allowed=True):
        headers.extend((k,str(v)) for k,v in part.items())
        for key,value in part.raw_items():
            try:decoded=''.join(c.decode(cs or 'ascii',errors='strict') if isinstance(c,bytes) else c for c,cs in decode_header(value))
            except (LookupError,UnicodeError) as e:raise ContentError('undecodable_content') from e
            decoded=re.sub(r'\r?\n[ \t]+',' ',decoded)
            if (key,decoded) not in headers:headers.append((key,decoded))
        if part.defects or any(getattr(v,'defects',()) for _,v in part.items()):raise ContentError('malformed_email')
        if part.get_filename() or part.get_content_disposition()=='attachment' or part.get_content_type()=='application/pdf':
            if not attachment_allowed or part.get_content_type()!='application/pdf' or part.is_multipart():raise ContentError('uninspected_attachment')
            attachments[0]+=1
            if attachments[0]>3:raise ContentError('attachment_count_limit')
            data=part.get_payload(decode=True)
            if part.defects or not isinstance(data,bytes):raise ContentError('undecodable_content')
            try:extracted=extract_pdf(data)
            except PDFError as error:raise ContentError(str(error)) from error
            if extracted['metadata']:headers.append(('X-Local-PDF-Info',extracted['metadata']))
            formats.append('application/pdf')
            return f"Attachment {attachments[0]} extracted text:\n"+extracted['text']
        if part.is_multipart():
            if part.get_content_type() not in {'multipart/mixed','multipart/alternative'}:raise ContentError('unsupported_mime')
            children=[visit(child,attachment_allowed and part.get_content_type()!='multipart/alternative') for child in part.iter_parts()]
            if not children:raise ContentError('empty_multipart')
            if part.get_content_type()=='multipart/alternative':
                canonical=lambda text:re.sub(r'\s+',' ',text).strip()
                if len({canonical(body) for body in children})!=1:raise ContentError('alternative_content_disagreement')
                return children[-1]
            return '\n\n'.join(children)
        kind=part.get_content_type()
        if kind not in {'text/plain','text/html'}:raise ContentError('uninspected_content')
        try:body=part.get_content(errors='strict')
        except Exception as e:raise ContentError('undecodable_content') from e
        if part.defects:raise ContentError('malformed_email')
        if not isinstance(body,str) or '\ufffd' in body:raise ContentError('undecodable_content')
        if kind=='text/html':body=html_to_text(body)
        formats.append(kind)
        return body
    body=visit(msg)
    return dict(subject=str(msg.get('Subject','')),body=body,headers=headers,input_formats=formats)
