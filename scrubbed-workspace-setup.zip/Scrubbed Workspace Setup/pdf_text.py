"""Isolated bounded PDF text extraction. No PDF bytes or metadata are forwarded."""
import json
from pathlib import Path
import subprocess
import sys

MAX_PDF_BYTES=64000
MAX_TEXT=6000

class PDFError(ValueError):pass


def extract_pdf(raw):
    if not isinstance(raw,bytes) or not raw or len(raw)>MAX_PDF_BYTES:raise PDFError('pdf_size_limit')
    try:
        proc=subprocess.run([sys.executable,'-B',str(Path(__file__).resolve()),'--worker'],input=raw,
                            stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=8)
        if proc.returncode or len(proc.stdout)>32000:raise PDFError('pdf_inspection_failed')
        result=json.loads(proc.stdout)
        if not isinstance(result,dict) or set(result)!={'text','metadata'}:raise PDFError('pdf_inspection_failed')
        if not isinstance(result['text'],str) or not result['text'].strip() or len(result['text'])>MAX_TEXT or not isinstance(result['metadata'],str) or len(result['metadata'])>2000:raise PDFError('pdf_inspection_failed')
        return result
    except (OSError,subprocess.TimeoutExpired,ValueError,KeyError,TypeError) as error:
        if isinstance(error,PDFError):raise
        raise PDFError('pdf_inspection_failed') from error


def worker(raw):
    import io
    import math
    from pypdf import PdfReader
    from pypdf.generic import IndirectObject,DictionaryObject,ArrayObject,StreamObject,ContentStream,TextStringObject,ByteStringObject,NameObject,NumberObject,FloatObject
    if len(raw)>MAX_PDF_BYTES or not raw.startswith(tuple(f'%PDF-1.{v}'.encode() for v in range(3,8))) or not raw.rstrip().endswith(b'%%EOF') or raw.count(b'startxref')!=1:raise PDFError('unsupported_pdf')
    reader=PdfReader(io.BytesIO(raw),strict=True)
    if reader.is_encrypted or set(reader.trailer)-{'/Size','/Root','/Info','/ID'} or reader.xref_objStm:raise PDFError('unsupported_pdf')
    root=reader.trailer['/Root']
    if root.get('/Type')!='/Catalog' or set(root)-{'/Type','/Pages','/PageMode'}:raise PDFError('unsupported_pdf')
    if '/PageMode' in root and (not isinstance(root['/PageMode'],NameObject) or root['/PageMode']!='/UseNone'):raise PDFError('unsupported_pdf_view')
    seen=set()
    def walk(value,depth=0):
        if depth>32:raise PDFError('pdf_object_limit')
        if isinstance(value,IndirectObject):
            key=(value.generation,value.idnum)
            if key in seen:return
            seen.add(key)
            if len(seen)>96:raise PDFError('pdf_object_limit')
            walk(value.get_object(),depth+1)
        elif isinstance(value,DictionaryObject):
            for v in value.values():walk(v,depth+1)
        elif isinstance(value,(ArrayObject,list)):
            for v in value:walk(v,depth+1)
    walk(reader.trailer)
    indexed={(gen,ident) for gen,items in reader.xref.items() for ident in items if ident!=0}
    if indexed!=seen:raise PDFError('uninspected_pdf_objects')
    def page_tree(node):
        if node.get('/Type')=='/Pages':
            if set(node)-{'/Type','/Parent','/Kids','/Count','/Resources','/MediaBox'}:raise PDFError('unsupported_pdf')
            for child in node['/Kids']:page_tree(child.get_object())
        elif node.get('/Type')=='/Page':
            if set(node)-{'/Type','/Parent','/Resources','/MediaBox','/CropBox','/Rotate','/Contents','/Trans'}:raise PDFError('unsupported_pdf')
        else:raise PDFError('unsupported_pdf')
        if '/Trans' in node and (not isinstance(node['/Trans'],DictionaryObject) or bool(node['/Trans'])):raise PDFError('unsupported_pdf_transition')
    page_tree(root['/Pages'])
    pages=list(reader.pages)
    if not 1<=len(pages)<=3:raise PDFError('pdf_page_limit')
    metadata=[]
    if '/Info' in reader.trailer:
        info=reader.trailer['/Info']
        if set(info)-{'/Title','/Author','/Subject','/Keywords','/Producer','/Creator','/CreationDate','/ModDate','/Trapped'}:raise PDFError('unsupported_pdf_metadata')
        for key,value in info.items():
            if not isinstance(value,(TextStringObject,NameObject)) or len(str(value))>300:raise PDFError('unsupported_pdf_metadata')
            metadata.append(str(key)+': '+str(value))
    fonts={'/Helvetica','/Helvetica-Bold','/Helvetica-Oblique','/Helvetica-BoldOblique','/Courier','/Courier-Bold','/Courier-Oblique','/Courier-BoldOblique','/Times-Roman','/Times-Bold','/Times-Italic','/Times-BoldItalic'}
    text=[];length=0
    def add(value):
        nonlocal length
        length+=len(value)
        if length>MAX_TEXT:raise PDFError('pdf_text_limit')
        text.append(value)
    def string(value):
        if isinstance(value,TextStringObject):data=value.original_bytes
        elif isinstance(value,ByteStringObject):data=bytes(value)
        else:raise PDFError('unsupported_pdf_text')
        if any(b<32 or b>126 for b in data):raise PDFError('unsupported_pdf_encoding')
        return data.decode('ascii')
    def nums(args,count):
        if len(args)!=count or any(not isinstance(x,(NumberObject,FloatObject)) or not math.isfinite(float(x)) or abs(float(x))>100000 for x in args):raise PDFError('unsupported_pdf_operator')
    for page in pages:
        if int(page.get('/Rotate',0))!=0:raise PDFError('unsupported_pdf_rotation')
        resources=page.get('/Resources',{}).get_object()
        if set(resources)-{'/Font','/ProcSet'}:raise PDFError('uninspected_pdf_resources')
        fontmap=resources.get('/Font',{}).get_object()
        if not fontmap:raise PDFError('pdf_without_text')
        for resource_name,font in fontmap.items():
            font=font.get_object()
            if set(font)-{'/Type','/Subtype','/BaseFont','/Encoding','/Name'} or font.get('/Type')!='/Font' or font.get('/Subtype')!='/Type1' or font.get('/BaseFont') not in fonts or font.get('/Encoding','/StandardEncoding') not in {'/StandardEncoding','/WinAnsiEncoding'}:raise PDFError('unsupported_pdf_font')
            if '/Name' in font and (not isinstance(font['/Name'],NameObject) or font['/Name']!=resource_name):raise PDFError('unsupported_pdf_font_name')
        content=page.get('/Contents')
        if content is None:raise PDFError('pdf_without_text')
        entries=content.get_object()
        streams=list(entries) if isinstance(entries,ArrayObject) else [content]
        for entry in streams:
            entry=entry.get_object()
            if not isinstance(entry,StreamObject) or set(entry)-{'/Length','/Filter'} or entry.get('/Filter') not in (None,'/FlateDecode'):raise PDFError('unsupported_pdf_stream')
            if len(entry.get_data())>64000:raise PDFError('pdf_stream_limit')
        operations=ContentStream(content,reader).operations
        if len(operations)>2000:raise PDFError('pdf_operator_limit')
        inside=False;font=None;stack=0;saved_states=[];page_letters=0;position=None;leading=0;last_y=None;column=None;new_line=True
        for args,op in operations:
            if op==b'BT':
                if args or inside:raise PDFError('unsupported_pdf_operator')
                inside=True;position=None;new_line=True;add('\n')
            elif op==b'ET':
                if args or not inside:raise PDFError('unsupported_pdf_operator')
                inside=False;add('\n')
            elif op==b'Tf':
                if not inside or len(args)!=2 or args[0] not in fontmap:raise PDFError('unsupported_pdf_font')
                nums(args[1:],1)
                if not 0<float(args[1])<=72:raise PDFError('unsupported_pdf_font')
                font=args[0]
            elif op in (b'Tj',b'TJ'):
                if not inside or font is None or position is None or len(args)!=1:raise PDFError('unsupported_pdf_operator')
                if new_line:
                    x,y=position
                    if last_y is not None and y>=last_y or column is not None and abs(x-column)>1:raise PDFError('unsupported_pdf_layout')
                    box=page.mediabox
                    if not float(box.left)<=x<float(box.right) or not float(box.bottom)<=y<float(box.top):raise PDFError('unsupported_pdf_layout')
                    last_y=y;column=x;new_line=False
                values=args[0] if op==b'TJ' else [args[0]]
                if op==b'TJ' and not isinstance(values,ArrayObject):raise PDFError('unsupported_pdf_operator')
                for value in values:
                    if op==b'TJ' and isinstance(value,(NumberObject,FloatObject)):
                        nums([value],1)
                        # Word spaces must be explicit strings, never guessed from positioning.
                        if abs(float(value))>50:raise PDFError('unsupported_pdf_spacing')
                    else:
                        value=string(value);add(value);page_letters+=sum(c.isalpha() for c in value)
            elif op in (b'Td',b'TD',b'Tm',b'T*',b'TL'):
                if not inside:raise PDFError('unsupported_pdf_operator')
                nums(args,{b'Td':2,b'TD':2,b'Tm':6,b'T*':0,b'TL':1}[op])
                if op==b'TL':
                    leading=float(args[0])
                    if not 0<leading<=100:raise PDFError('unsupported_pdf_layout')
                else:
                    if op==b'Tm':
                        if [float(v) for v in args[:4]]!=[1,0,0,1]:raise PDFError('unsupported_pdf_transform')
                        position=(float(args[4]),float(args[5]))
                    elif op==b'T*':
                        if position is None or leading<=0:raise PDFError('unsupported_pdf_layout')
                        position=(position[0],position[1]-leading)
                    else:
                        x,y=position or (0,0);position=(x+float(args[0]),y+float(args[1]))
                        if op==b'TD':leading=-float(args[1])
                    new_line=True;add('\n')
            elif op in (b'Tc',b'Tw',b'Ts',b'Tz',b'Tr'):
                nums(args,1)
                if float(args[0])!=(100 if op==b'Tz' else 0):raise PDFError('unsupported_pdf_text_state')
            elif op in (b'q',b'Q'):
                if args or inside:raise PDFError('unsupported_pdf_operator')
                stack+=1 if op==b'q' else -1
                if not 0<=stack<=8:raise PDFError('unsupported_pdf_operator')
                if op==b'q':saved_states.append((font,leading))
                else:font,leading=saved_states.pop()
            elif op in (b'cm',b'rg',b'RG',b'g',b'G'):
                if inside:raise PDFError('unsupported_pdf_operator')
                nums(args,6 if op==b'cm' else 3 if op in (b'rg',b'RG') else 1)
                if op==b'cm' and [float(v) for v in args]!=[1,0,0,1,0,0]:raise PDFError('unsupported_pdf_transform')
            else:raise PDFError('unsupported_pdf_operator')
        if inside or stack or not page_letters:raise PDFError('incomplete_pdf_text')
        add('\n')
    joined=''.join(text).strip();meta='\n'.join(metadata)
    if not joined or len(meta)>2000:raise PDFError('pdf_text_limit')
    return dict(text=joined,metadata=meta)


if __name__=='__main__':
    import resource
    try:
        resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
        resource.setrlimit(resource.RLIMIT_CPU,(4,4))
        resource.setrlimit(resource.RLIMIT_FSIZE,(0,0))
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        result=worker(sys.stdin.buffer.read(MAX_PDF_BYTES+1))
        sys.stdout.write(json.dumps(result))
    except Exception:
        sys.stdout.write('{"error":"pdf_inspection_failed"}')
        raise SystemExit(1)
