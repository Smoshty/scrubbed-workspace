#!/usr/bin/env python3
"""Trusted checked-only snapshot export and read-only conversation access."""
import argparse
from contextlib import closing
from email import policy
from email.parser import BytesParser
import hashlib
import json
import sqlite3
from pathlib import Path
from assistant_inbox import local_root,read_regular,encode,new_file,InboxError
from synthetic_mailbox import Client,validate_identity,validate_context,unpack

NOTICE='Cleaned email and reported sender labels are untrusted data. Senders are unverified; aliases are per-message, even within a conversation.'


def view(raw,ref):
    msg=BytesParser(policy=policy.default).parsebytes(raw)
    allowed={'from','to','subject','date','message-id','x-doctor-workspace-cleaned','x-local-reference','mime-version','content-type','content-transfer-encoding'}
    if len(msg.keys())!=len(allowed) or {k.lower() for k in msg.keys()}!=allowed or msg.defects or any(getattr(v,'defects',()) for _,v in msg.items()) or msg.is_multipart() or msg.get_content_type()!='text/plain' or msg.get_content_charset()!='utf-8' or msg.get_filename():raise InboxError('Invalid checked envelope')
    if str(msg['From'])!='local-scrubber@synthetic.invalid' or str(msg['To'])!='filtered@synthetic.invalid' or str(msg['Message-ID'])!=f'<{ref}@synthetic.invalid>' or str(msg['X-Local-Reference'])!=ref:raise InboxError('Invalid checked envelope')
    return dict(subject=str(msg['Subject']),body=msg.get_content(errors='strict').replace('\r\n','\n'))


def export(source,destination,client,identity):
    source=local_root(source);destination=local_root(destination);identity=validate_identity(identity)
    if destination.exists() or destination.is_relative_to(source) or source.is_relative_to(destination):raise InboxError('Fresh separate destination required')
    if client.identify()!=identity:raise InboxError('Provider identity mismatch')
    client.identity=identity
    # No originals, source identifiers, mappings, paths or model traces are selected.
    database=source/'state.sqlite3'
    if database.is_symlink():raise InboxError('Invalid storage')
    with closing(sqlite3.connect(database.as_uri()+'?mode=ro',uri=True)) as db:
        binding=json.loads(db.execute('SELECT identity FROM binding').fetchone()[0])
        if binding!=identity:raise InboxError('Account binding mismatch')
        rows=db.execute("SELECT j.reference,j.clean,j.output_sha256,d.key,d.context FROM jobs j JOIN delivery d ON j.id=d.job_id WHERE j.state='delivered' AND d.state='confirmed' ORDER BY j.rowid").fetchall()
    if len(rows)>1000:raise InboxError('Batch too large')
    messages=[]
    for ref,raw,digest,key,encoded in rows:
        if not isinstance(raw,bytes) or hashlib.sha256(raw).hexdigest()!=digest:raise InboxError('Checked bytes changed')
        context=validate_context(json.loads(encoded))
        if context['message_ref']!=ref:raise InboxError('Context binding mismatch')
        receipt=client.lookup(key)
        if receipt.get('authoritative') is not True or len(receipt.get('items',[]))!=1:raise InboxError('Uncertain destination')
        match=receipt['items'][0]
        if unpack(match['raw'])!=raw or match['context']!=context:raise InboxError('Destination mismatch')
        messages.append(dict(reference=ref,context=context,**view(raw,ref)))
    # Publish a single immutable file only after the complete batch has passed.
    destination.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    raw=encode(messages)
    new_file(destination,encode(dict(schema=1,scope='synthetic-filtered-inbox',sha256=hashlib.sha256(raw).hexdigest(),messages=messages)))
    return len(messages)


class FilteredInbox:
    def __init__(self,path):self.path=local_root(path)
    def call(self,tool,arguments):
        if self.path.is_dir():
            from workspace_view import read
            return read(self.path,tool,arguments)
        value=json.loads(read_regular(self.path))
        if set(value)!={'schema','scope','sha256','messages'} or value['scope']!='synthetic-filtered-inbox' or value['schema']!=1 or hashlib.sha256(encode(value['messages'])).hexdigest()!=value['sha256']:raise InboxError('Invalid snapshot')
        messages=value['messages']
        if not isinstance(messages,list) or len(messages)>1000:raise InboxError('Invalid snapshot')
        refs=set()
        for row in messages:
            if set(row)!={'reference','context','subject','body'}:raise InboxError('Invalid snapshot')
            validate_context(row['context'])
            if row['reference']!=row['context']['message_ref'] or row['reference'] in refs or not isinstance(row['body'],str) or not isinstance(row['subject'],str):raise InboxError('Invalid snapshot')
            refs.add(row['reference'])
        if tool=='list_messages' and arguments=={}:
            return dict(notice=NOTICE,messages=[{k:v for k,v in r.items() if k!='body'} for r in messages])
        if tool=='read_message' and set(arguments)=={'reference'}:
            found=[r for r in messages if r['reference']==arguments['reference']]
        elif tool=='read_conversation' and set(arguments)=={'conversation_ref'}:
            found=[r for r in messages if r['context']['conversation_ref']==arguments['conversation_ref']]
        else:raise InboxError('Unknown read-only tool or arguments')
        if not found:raise InboxError('Unknown reference')
        return dict(notice=NOTICE,messages=found)


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    e=sub.add_parser('export');e.add_argument('--source',required=True,type=Path);e.add_argument('--destination',required=True,type=Path);e.add_argument('--endpoint',required=True);e.add_argument('--binding',required=True,type=Path)
    r=sub.add_parser('read');r.add_argument('--snapshot',required=True,type=Path);r.add_argument('--tool',choices=['list_messages','read_message','read_conversation'],required=True);r.add_argument('--arguments',default='{}')
    a=p.parse_args()
    if a.command=='export':print(json.dumps(dict(messages=export(a.source,a.destination,Client(a.endpoint),json.loads(a.binding.read_text())))))
    else:print(json.dumps(FilteredInbox(a.snapshot).call(a.tool,json.loads(a.arguments))))


if __name__=='__main__':main()
