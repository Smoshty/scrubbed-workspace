#!/usr/bin/env python3
"""Real outage beyond three attempts, watcher restart and automatic checked recovery."""
import argparse
from datetime import datetime,timezone
from email import policy
from email.parser import BytesParser
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from benchmark.run import build_message,digest,listening,stop,catalog
from mail_pipeline import initialize,atomic_file,database
from sanitizer import literal_matches,MODEL


def stop_worker(worker):
    if worker and worker.poll() is None:
        os.killpg(worker.pid,signal.SIGTERM)
        try:worker.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(worker.pid,signal.SIGKILL);worker.wait()


def wait_for(condition,proc,description,timeout=240):
    until=time.monotonic()+timeout
    while time.monotonic()<until:
        if proc is not None and proc.poll() is not None:raise RuntimeError('Owned process exited: '+description)
        if condition():return
        time.sleep(.2)
    raise RuntimeError('Timed out: '+description)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True,type=Path);args=p.parse_args()
    root=args.root.resolve()
    if root.exists() or not root.is_relative_to(ROOT/'data'):raise ValueError('Use a fresh project data root')
    if listening():raise RuntimeError('Refusing occupied model port')
    freeze=json.loads((ROOT/'flow/recovery-freeze-v1.json').read_text())
    def frozen():
        for name,expected in freeze['files'].items():
            if digest((ROOT/name).read_bytes())!=expected:raise RuntimeError('Frozen input changed: '+name)
    frozen();root.mkdir(mode=0o700);box=initialize(root/'mailbox')
    cases=json.loads((ROOT/'flow/recovery-cases-v1.json').read_text())['cases'];originals={c['id']:build_message(c) for c in cases}
    report=dict(complete=False,scope='Synthetic real model-unavailable recovery, not a model-quality benchmark',freeze=freeze,started_at=datetime.now(timezone.utc).isoformat(),checks={},results=[])
    def save():atomic_file(root/'report.json',(json.dumps(report,indent=2)+'\n').encode())
    def jobs():
        with database(box/'state.sqlite3') as db:return {c['id']:dict(db.execute('SELECT * FROM jobs WHERE id=?',(digest(originals[c['id']]),)).fetchone()) for c in cases if db.execute('SELECT 1 FROM jobs WHERE id=?',(digest(originals[c['id']]),)).fetchone()}
    def wires():return {x.name:digest(x.read_bytes()) for x in (box/'filtered').glob('*.eml')}
    logs=[];worker=None;server=None
    def start_worker():
        log=(root/f'worker-{len(logs)}.log').open('w');logs.append(log)
        return subprocess.Popen([str(ROOT/'simulate-mail'),'--root',str(box),'watch','--poll','.2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True),log
    save()
    try:
        worker,log=start_worker()
        for case in cases:atomic_file(box/'incoming'/(case['id']+'.eml'),originals[case['id']])
        def paused():
            rows=jobs()
            return len(rows)==4 and all(rows[c['id']]['state']==('waiting' if c['expected']=='delivered' else 'held') for c in cases)
        wait_for(paused,worker,'three failures persist as infrastructure waiting',120)
        rows=jobs();assert all(rows[c['id']]['attempts']>=3 for c in cases if c['expected']=='delivered') and not wires()
        initial={key:{k:row[k] for k in ['state','reason','attempts','retry_failures','next_attempt']} for key,row in rows.items()}
        protected={key:(row['state'],row['reason'],row['attempts']) for key,row in rows.items() if row['state']=='held'}
        report['outage_rows']=initial;report['checks']['past_old_attempt_limit_no_output']=True;save()
        print('Past old three-attempt limit: two waiting, two held, no copies.',flush=True)
        stop_worker(worker);worker,log=start_worker()
        def restarted():
            try:
                values=[json.loads(line) for line in Path(log.name).read_text().splitlines() if line.startswith('{')]
                return bool(values) and values[-1]['states'].get('waiting')==2
            except (ValueError,KeyError):return False
        wait_for(restarted,worker,'restarted watcher observes persistent waiting',30)
        rows=jobs();assert all(rows[key]['next_attempt']==v['next_attempt'] and rows[key]['attempts']==v['attempts'] for key,v in initial.items())
        report['checks']['worker_restart_preserved_backoff_and_holds']=True
        atomic_file(box/'incoming/duplicate.eml',originals['care'])
        # Restore only the owned model; never invoke retry or edit scheduling state.
        model_log=(root/'model.log').open('w');logs.append(model_log)
        server=subprocess.Popen([str(ROOT/'local-ollama'),'serve'],cwd=ROOT,stdout=model_log,stderr=subprocess.STDOUT,start_new_session=True)
        wait_for(listening,server,'owned model recovery',30);report['model']=next(m for m in catalog() if m['name']==MODEL);save()
        wait_for(lambda:len(wires())==2,worker,'automatic full inspection and publication',360)
        frozen();rows=jobs()
        for case in cases:
            row=rows[case['id']];target=box/'filtered'/(row['reference']+'.eml')
            result=dict(id=case['id'],state=row['state'],reason=row['reason'],attempts=row['attempts'],source_unchanged=(box/'incoming'/(case['id']+'.eml')).read_bytes()==originals[case['id']])
            if case['expected']=='delivered':
                raw=target.read_bytes();msg=BytesParser(policy=policy.default).parsebytes(raw);text=str(msg['Subject'])+'\n'+msg.get_content()
                result.update(missing_keep=[i for i,v in enumerate(case['keep']) if v.casefold() not in text.casefold()],leaked=[i for i,v in enumerate(case['forbidden']) if literal_matches(v,text)],
                              checked_bytes=raw==row['clean'] and digest(raw)==row['output_sha256'],full_checks_recorded=json.loads(row['audit'])['version']=='context-sanitizer-6',
                              counters_reset=row['retry_failures']==0 and row['interruptions']==0,cleaned_subject=str(msg['Subject']),cleaned_body=msg.get_content())
            else:result.update(no_output=not target.exists(),unchanged_hold=(row['state'],row['reason'],row['attempts'])==protected[case['id']])
            result['passed']=row['state']==case['expected'] and result['source_unchanged'] and not result.get('missing_keep') and not result.get('leaked') and all(result.get(k,True) for k in ['checked_bytes','full_checks_recorded','counters_reset','no_output','unchanged_hold'])
            report['results'].append(result)
        report['checks']['automatic_recovery_without_retry_command']=all(rows[c['id']]['state']==c['expected'] for c in cases)
        before=wires();counts={k:v['attempts'] for k,v in rows.items()}
        stop_worker(worker);worker=None;stop(server);server=None
        offline=subprocess.run([str(ROOT/'simulate-mail'),'--root',str(box),'run'],cwd=ROOT,capture_output=True,text=True,timeout=40)
        with database(box/'state.sqlite3') as db:arrivals=db.execute('SELECT count(*) FROM arrivals').fetchone()[0]
        report['checks']['duplicate_and_offline_restart_unchanged']=offline.returncode==0 and arrivals==5 and wires()==before and counts=={k:v['attempts'] for k,v in jobs().items()}
        report['checks']['only_two_checked_copies']=len(wires())==2
        report['complete']=True;report['passed']=all(report['checks'].values()) and all(x['passed'] for x in report['results']);save()
    finally:
        stop_worker(worker)
        if server:stop(server)
        for log in logs:log.close()
    if not report['passed']:raise SystemExit('Recovery acceptance failed; preserve evidence')


if __name__=='__main__':main()
