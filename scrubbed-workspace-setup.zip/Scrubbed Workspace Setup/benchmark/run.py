"""Fixed-input local mailbox benchmark. Owns its test server; no real transport."""
import argparse
from datetime import datetime,timezone
import hashlib
import http.client
import importlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import socket
import statistics
import subprocess
import sys
import time
from types import SimpleNamespace
from email import policy
from email.message import EmailMessage
from email.parser import BytesParser
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from mail_pipeline import Pipeline,atomic_file,database,initialize,production_processor
from sanitizer import literal_matches


def digest(raw):return hashlib.sha256(raw).hexdigest()


def build_message(case):
    msg=EmailMessage();msg['From']='source@synthetic.invalid';msg['To']='doctor@synthetic.invalid';msg['Subject']=case['subject']
    msg.set_content(case['body'],subtype='html' if case.get('html') else 'plain')
    if case.get('attachment'):
        msg.add_attachment(b'Fictional benchmark attachment',maintype='application',subtype='pdf',filename='synthetic.pdf')
        msg.set_boundary('synthetic-benchmark-v1-boundary')
    return msg.as_bytes()


def assess(case,source,target,row):
    result={'state':row['state'],'reason':row['reason'],
            'source_unchanged':source.read_bytes()==build_message(case),
            'expected':case['expected'],'state_correct':row['state']==case['expected']}
    if row['state']=='delivered':
        raw=target.read_bytes();msg=BytesParser(policy=policy.default).parsebytes(raw)
        text=str(msg['Subject'])+'\n'+msg.get_content()
        result.update(missing_keep=[i for i,v in enumerate(case['keep']) if v.casefold() not in text.casefold()],
                      leaked=[i for i,v in enumerate(case['forbidden']) if literal_matches(v,text)],
                      wire_matches_database=raw==row['clean'] and digest(raw)==row['output_sha256'],
                      output_sha256=digest(raw))
    else:result.update(no_output=not target.exists(),not_delivered_keep=list(range(len(case['keep']))))
    result['passed']=result['state_correct'] and result['source_unchanged'] and not result.get('missing_keep') and not result.get('leaked') and result.get('wire_matches_database',True) and result.get('no_output',True)
    return result


def summarize(rows):
    called=[r['workflow_seconds'] for r in rows if r['calls']]
    required=sum(r['required_keep'] for r in rows)
    missing=sum(len(r.get('missing_keep',[])) for r in rows)
    withheld=sum(len(r.get('not_delivered_keep',[])) for r in rows)
    calls=[call for r in rows for call in r['calls']]
    return {'cases':len(rows),'passed_cases':sum(r['passed'] for r in rows),
            'delivered':sum(r['state']=='delivered' for r in rows),
            'unexpected_delivery':sum(r['state']=='delivered' and r['expected']!='delivered' for r in rows),
            'marked_identifier_leaks':sum(len(r.get('leaked',[])) for r in rows),
            'unnecessary_holds':sum(r['state']=='held' and r['expected']=='delivered' for r in rows),
            'unfinished_jobs':sum(r['state'] not in {'delivered','held'} for r in rows),
            'missing_phrases_in_copies':missing,'phrases_lost_to_withholding':withheld,
            'required_phrases':required,'retained_phrases':required-missing-withheld,
            'model_calls':len(calls),'incomplete_or_unreadable_responses':sum(not c['completed_json_response'] for c in calls),
            'total_workflow_seconds':round(sum(r['workflow_seconds'] for r in rows),6),
            'median_model_invoked_workflow_seconds':statistics.median(called) if called else None,
            'first_model_invoked_workflow_seconds':called[0] if called else None,
            'subsequent_model_invoked_median_seconds':statistics.median(called[1:]) if len(called)>1 else None,
            'timing_totals':{key:sum(c[key] for c in calls if key in c) for key in ['load_seconds','prompt_seconds','generation_seconds']},
            'timing_observation_counts':{key:sum(key in c for c in calls) for key in ['load_seconds','prompt_seconds','generation_seconds']}}


def listening():
    with socket.socket() as sock:
        sock.settimeout(.2);return sock.connect_ex(('127.0.0.1',11435))==0


def stop(server):
    if server.poll() is None:
        os.killpg(server.pid,signal.SIGTERM)
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
    until=time.monotonic()+10
    while listening() and time.monotonic()<until:time.sleep(.1)
    if listening():raise RuntimeError('Owned test server did not release its port')


def catalog():
    connection=http.client.HTTPConnection('127.0.0.1',11435,timeout=5)
    try:
        connection.request('GET','/api/tags');response=connection.getresponse()
        if response.status!=200:raise RuntimeError('Cannot read project model catalog')
        return json.loads(response.read())['models']
    finally:connection.close()


def runtime_overrides(config):
    overrides=config.get('runtime_env')
    if overrides is None:return {}
    if not isinstance(overrides,dict) or set(overrides)!={'LLAMA_ARG_THREADS'} or overrides['LLAMA_ARG_THREADS'] not in ('4','8'):
        raise ValueError('Only explicit four/eight-thread test overrides are supported')
    return dict(overrides)


def observed_runtime(text,overrides):
    found={(int(a),int(b)) for a,b in re.findall(r'system_info: n_threads = (\d+) \(n_threads_batch = (\d+)\)',text)}
    expected=int(overrides['LLAMA_ARG_THREADS'])
    if found!={(expected,expected)}:raise RuntimeError('Runtime thread override was not consistently observed')
    return dict(generation_threads=expected,prompt_threads=expected)


def frozen_inputs(freeze_path=None):
    directory=Path(__file__).resolve().parent
    path=Path(freeze_path).resolve() if freeze_path else directory/'freeze-v1.json'
    if not path.is_relative_to(directory):raise ValueError('Keep benchmark freezes project-local')
    directory=path.parent
    freeze=json.loads(path.read_text())
    for name,expected in freeze['files'].items():
        target=(directory/name).resolve()
        if not target.is_relative_to(directory):raise ValueError('Frozen input escaped benchmark directory')
        if digest(target.read_bytes())!=expected:raise ValueError('Frozen benchmark input changed: '+name)
    for name,expected in freeze.get('code_files',{}).items():
        target=(ROOT/name).resolve()
        if not target.is_relative_to(ROOT) or digest(target.read_bytes())!=expected:raise ValueError('Frozen code changed: '+name)
    case_file=freeze.get('case_file','cases-v1.json');config_file=freeze.get('config_file','configs-v1.json')
    if case_file not in freeze['files'] or config_file not in freeze['files']:raise ValueError('Corpus/configuration must be hashed in freeze')
    cases=json.loads((directory/case_file).read_text())['cases']
    settings=json.loads((directory/config_file).read_text())
    if settings['settings']!={'think':False,'temperature':0,'num_ctx':16384,'num_predict':1024}:raise ValueError('Unsupported benchmark settings')
    for config in settings['configurations']:runtime_overrides(config)
    return cases,settings,freeze


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--freeze',type=Path);parser.add_argument('--trace-synthetic',action='store_true');args=parser.parse_args()
    root=args.root.resolve()
    if not root.is_relative_to(ROOT/'data') or root.exists():raise ValueError('Use a new project data root')
    if listening():raise RuntimeError('Project model port is already in use; benchmark will not stop an existing service')
    cases,settings,freeze=frozen_inputs(args.freeze);root.mkdir(parents=True,mode=0o700)
    originals={case['id']:build_message(case) for case in cases}
    source_dir=root/'frozen-sources';source_dir.mkdir(mode=0o700)
    for name,raw in originals.items():atomic_file(source_dir/(name+'.eml'),raw)
    cpu_info=Path('/proc/cpuinfo').read_text() if Path('/proc/cpuinfo').exists() else ''
    cpu_model=next((line.split(':',1)[1].strip() for line in cpu_info.splitlines() if line.startswith('model name')),platform.processor())
    report={'started_at':datetime.now(timezone.utc).isoformat(),'complete':False,'scope':'Synthetic developer-authored regression baseline; no clinical validation or Mac performance claim',
            'freeze':freeze,'settings':settings['settings'],'hardware':{'platform':platform.platform(),'logical_cpus':os.cpu_count(),'cpu_model':cpu_model,'python':sys.version},
            'source_sha256':{name:digest(raw) for name,raw in originals.items()},
            'code_sha256':{name:digest((ROOT/name).read_bytes()) for name in ['sanitizer.py','experimental_sanitizer.py','mail_content.py','model_metrics.py','context_sanitizer.py','compact_sanitizer.py','array_sanitizer.py','mail_pipeline.py','benchmark/run.py']},'configurations':[]}
    report['synthetic_decision_trace']=args.trace_synthetic
    for name in report['code_sha256']:
        snapshot=root/'code-snapshots'/name;snapshot.parent.mkdir(parents=True,exist_ok=True)
        atomic_file(snapshot,(ROOT/name).read_bytes())
    def save():atomic_file(root/'report.json',(json.dumps(report,indent=2)+'\n').encode())
    save()
    for config in settings['configurations']:
        if listening():raise RuntimeError('Project model port became occupied between configurations')
        mailbox=initialize(root/config['id']);entry=dict(config,results=[]);report['configurations'].append(entry);save()
        with (root/(config['id']+'-server.log')).open('w') as log:
            started=time.monotonic()
            overrides=runtime_overrides(config)
            environment=dict(os.environ,**overrides)
            server=subprocess.Popen([str(ROOT/'local-ollama'),'serve'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=environment)
            try:
                until=time.monotonic()+20
                while not listening():
                    if server.poll() is not None or time.monotonic()>until:raise RuntimeError('Project test server failed to start')
                    time.sleep(.1)
                if server.poll() is not None:raise RuntimeError('Project test server exited during startup')
                entry['server_start_seconds']=time.monotonic()-started
                model=next((m for m in catalog() if m['name']==config['model']),None)
                if model is None:raise ValueError('Required local model is not installed')
                entry['model_digest']=model['digest'];entry['model_details']=model.get('details',{})
                module=importlib.import_module({'conservative':'sanitizer','retention-pilot':'experimental_sanitizer','focused-roles':'context_sanitizer','compact-discovery':'compact_sanitizer','array-discovery':'array_sanitizer'}[config['policy']])
                if args.trace_synthetic:
                    policy_module=module
                    class TracedModel(policy_module.LocalModel):
                        def ask(self,system,payload,schema):
                            result=super().ask(system,payload,schema)
                            with (mailbox/'synthetic-decisions.jsonl').open('a') as trace:
                                trace.write(json.dumps(dict(system=system,payload=payload,result=result))+'\n')
                            return result
                    module=SimpleNamespace(**vars(policy_module));module.LocalModel=TracedModel
                setup=time.monotonic();process,fingerprint=production_processor(config['model'],sanitizer_module=module)
                entry['setup_seconds']=time.monotonic()-setup
                if overrides:
                    entry['screening_fingerprint']=fingerprint
                    fingerprint=digest(json.dumps(dict(screening=fingerprint,runtime_env=overrides),sort_keys=True).encode())
                entry['fingerprint']=fingerprint
                if process.model_settings!=settings['settings']:raise RuntimeError('Actual model settings do not match frozen benchmark settings')
                worker=Pipeline(mailbox,process,fingerprint)
                for case in cases:
                    source=mailbox/'incoming'/(case['id']+'.eml');atomic_file(source,originals[case['id']])
                    first=len(process.model_metrics);started=time.monotonic();status=worker.run_once();elapsed=time.monotonic()-started
                    if status['input_errors']:raise RuntimeError('Benchmark input error')
                    with database(mailbox/'state.sqlite3') as db:
                        row=dict(db.execute('SELECT * FROM jobs WHERE id=?',(digest(originals[case['id']]),)).fetchone())
                    target=mailbox/'filtered'/(row['reference']+'.eml')
                    result=assess(case,source,target,row)
                    result.update(id=case['id'],required_keep=len(case['keep']),workflow_seconds=round(elapsed,6),calls=process.model_metrics[first:])
                    entry['results'].append(result);entry['summary']=summarize(entry['results'])
                    if overrides and result['calls']:
                        entry['observed_runtime']=observed_runtime((root/(config['id']+'-server.log')).read_text(),overrides)
                    save()
                    print(json.dumps({'configuration':config['id'],'case':case['id'],'state':row['state'],'passed':result['passed'],'seconds':round(elapsed,2)}),flush=True)
                with database(mailbox/'state.sqlite3') as db:
                    delivered=db.execute("SELECT count(*) FROM jobs WHERE state='delivered'").fetchone()[0]
                if len(list((mailbox/'filtered').glob('*.eml')))!=delivered:raise RuntimeError('Unexpected destination files')
            finally:stop(server)
        for case in cases:
            if (source_dir/(case['id']+'.eml')).read_bytes()!=originals[case['id']]:raise RuntimeError('Frozen source changed')
        entry['originals_unchanged']=all((mailbox/'incoming'/(case['id']+'.eml')).read_bytes()==originals[case['id']] for case in cases)
        if not entry['originals_unchanged']:raise RuntimeError('Mailbox source changed')
        save()
    if report['code_sha256']!={name:digest((ROOT/name).read_bytes()) for name in report['code_sha256']}:raise RuntimeError('Code changed during benchmark')
    frozen_inputs(args.freeze);report['complete']=True;report['finished_at']=datetime.now(timezone.utc).isoformat();save()
    print('Benchmark complete. Quality failures remain failures; default configuration is unchanged.',flush=True)

if __name__=='__main__':main()
