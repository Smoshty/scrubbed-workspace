#!/usr/bin/env python3
"""Durable synthetic mailbox simulation. There is deliberately no email transport."""
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import stat
import time
import sanitizer

ROOT=Path(__file__).resolve().parent
MAX_ATTEMPTS=3
MAX_RETRY_DELAY=300
INFRASTRUCTURE_REASONS={'model_unavailable'}


def retry_delay(failures):
    return min(MAX_RETRY_DELAY,5*2**min(max(failures,0),6))
# Synthetic bridge default; historical conservative policy remains explicitly available.
DEFAULT_POLICY='preserve'
POLICIES={'preserve':'context_sanitizer','conservative':'sanitizer'}


def policy_module(name):
    import importlib
    if name not in POLICIES:raise ValueError('Unknown sanitization policy')
    return importlib.import_module(POLICIES[name])

@contextmanager
def database(path):
    fd=os.open(path,os.O_CREAT|os.O_RDWR,0o600);os.close(fd)
    db=sqlite3.connect(path);db.row_factory=sqlite3.Row
    try:
        with db:yield db
    finally:db.close()


def atomic_file(path,raw,exclusive=False):
    temp=path.with_name('.'+path.name+'.'+secrets.token_hex(8)+'.tmp')
    fd=os.open(temp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    try:
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        if exclusive:
            try:os.link(temp,path)
            except FileExistsError:
                if path.is_symlink() or path.read_bytes()!=raw:raise sanitizer.Hold('destination_conflict')
        else:os.replace(temp,path)
        directory=os.open(path.parent,os.O_RDONLY)
        try:os.fsync(directory)
        finally:os.close(directory)
    finally:
        temp.unlink(missing_ok=True)


def initialize(root):
    raw_path=Path(root).absolute()
    if raw_path.is_symlink():raise ValueError('Mailbox root cannot be a symlink')
    root=raw_path.resolve()
    if not root.is_relative_to(ROOT):raise ValueError('Keep synthetic mailboxes inside this project')
    marker=root/'scope.json'
    if root.exists() and not marker.exists() and any(root.iterdir()):raise ValueError('Refusing an unmarked nonempty mailbox directory')
    root.mkdir(parents=True,exist_ok=True,mode=0o700)
    if marker.is_symlink():raise ValueError('Invalid marker')
    if marker.exists():
        value=json.loads(marker.read_text())
        if value.get('scope')!='synthetic' or value.get('schema')!=1:raise ValueError('Synthetic scope marker required')
    else:atomic_file(marker,json.dumps(dict(scope='synthetic',schema=1,id=secrets.token_hex(16))).encode())
    for name in ['incoming','filtered','exceptions']:
        path=root/name
        if path.is_symlink():raise ValueError('Mailbox directories cannot be symlinks')
        path.mkdir(exist_ok=True,mode=0o700)
    path=root/'state.sqlite3'
    if path.is_symlink():raise ValueError('Database cannot be a symlink')
    with database(path) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS jobs(
          id TEXT PRIMARY KEY, reference TEXT UNIQUE NOT NULL, original BLOB,
          state TEXT NOT NULL, reason TEXT, attempts INTEGER NOT NULL DEFAULT 0,
          next_attempt REAL NOT NULL DEFAULT 0, clean BLOB, output_sha256 TEXT,
          mapping TEXT, audit TEXT, fingerprint TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        columns={r[1] for r in db.execute('PRAGMA table_info(jobs)')}
        for name in ['retry_failures','interruptions']:
            if name not in columns:db.execute(f'ALTER TABLE jobs ADD COLUMN {name} INTEGER NOT NULL DEFAULT 0')
        db.execute('CREATE TABLE IF NOT EXISTS arrivals(name TEXT,job_id TEXT,PRIMARY KEY(name,job_id))')
        db.execute('CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,job_id TEXT,kind TEXT,at TEXT DEFAULT CURRENT_TIMESTAMP)')
    return root


class Pipeline:
    def __init__(self,root,processor,fingerprint,clock=time.time,crash_hook=None):
        self.root=initialize(root);self.path=self.root/'state.sqlite3'
        with database(self.path) as db:
            if not getattr(self,'provider_mode',False) and db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='binding'").fetchone():
                raise ValueError('Provider mailbox requires the separate simulate-inbox bridge')
        self.processor,self.fingerprint,self.clock=processor,fingerprint,clock
        self.crash_hook=crash_hook or (lambda *args:None)
    @contextmanager
    def locked(self):
        path=self.root/'.worker.lock'
        if path.is_symlink():raise ValueError('Invalid worker lock')
        fd=os.open(path,os.O_CREAT|os.O_RDWR,0o600)
        try:
            try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError as e:raise ValueError('Another worker is already running') from e
            yield
        finally:os.close(fd)
    def event(self,db,ident,kind):db.execute('INSERT INTO events(job_id,kind) VALUES (?,?)',(ident,kind))
    def scan(self):
        errors=0
        for path in sorted((self.root/'incoming').glob('*.eml')):
            try:
                fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
                with os.fdopen(fd,'rb') as f:
                    before=os.fstat(f.fileno())
                    if not stat.S_ISREG(before.st_mode):raise ValueError('not regular')
                    digest=hashlib.sha256();data=bytearray();size=0
                    while block:=f.read(65536):
                        digest.update(block);size+=len(block)
                        if size<=sanitizer.screener.MAX_BYTES:data.extend(block)
                    after=os.fstat(f.fileno())
                    if size!=before.st_size or (before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ValueError('source changed during capture')
                ident=digest.hexdigest();oversized=size>sanitizer.screener.MAX_BYTES
                with database(self.path) as db:
                    cur=db.execute('INSERT OR IGNORE INTO jobs(id,reference,original,state,reason) VALUES (?,?,?,?,?)',
                        (ident,secrets.token_hex(16),None if oversized else bytes(data),'held' if oversized else 'queued','message_too_large' if oversized else None))
                    db.execute('INSERT OR IGNORE INTO arrivals VALUES (?,?)',(path.name,ident))
                    if cur.rowcount:self.event(db,ident,'received')
            except (OSError,ValueError):errors+=1
        return errors
    def exception_file(self,job):
        path=self.root/'exceptions'/(job['reference']+'.json')
        if job['state'] in {'held','retry','waiting'}:
            value=dict(reference=job['reference'],state=job['state'],reason=job['reason'],attempts=job['attempts'],
                       note=('Waiting for the local model; automatic retry scheduled. No copy published.' if job['state']=='waiting' else 'Original retained in incoming and/or private state; no destination email published.'))
            if job['state'] in {'retry','waiting'}:value['retry_at']=job['next_attempt']
            atomic_file(path,(json.dumps(value,indent=2)+'\n').encode())
        else:path.unlink(missing_ok=True)
    def publish(self,job):
        if job['fingerprint']!=self.fingerprint:
            with database(self.path) as db:
                db.execute("UPDATE jobs SET state='retry',reason='configuration_changed',clean=NULL,output_sha256=NULL,mapping=NULL,audit=NULL,next_attempt=0 WHERE id=?",(job['id'],))
                self.event(db,job['id'],'configuration_changed')
            return
        raw=job['clean']
        if raw is None or hashlib.sha256(raw).hexdigest()!=job['output_sha256']:raise sanitizer.Hold('stored_output_corrupt')
        destination=self.root/'filtered'/(job['reference']+'.eml')
        atomic_file(destination,raw,exclusive=True)
        self.crash_hook('after_publish',job)
        with database(self.path) as db:
            db.execute("UPDATE jobs SET state='delivered',reason='verified_local_copy',updated_at=CURRENT_TIMESTAMP WHERE id=?",(job['id'],))
            self.event(db,job['id'],'published')
        (self.root/'exceptions'/(job['reference']+'.json')).unlink(missing_ok=True)
    def set_failure(self,job,error):
        retryable=isinstance(error,sanitizer.Retryable)
        failures=job.get('retry_failures',0)+1 if retryable else 0
        infrastructure=retryable and error.reason in INFRASTRUCTURE_REASONS
        state=('waiting' if failures>=MAX_ATTEMPTS else 'retry') if infrastructure else ('retry' if retryable and failures<MAX_ATTEMPTS else 'held')
        with database(self.path) as db:
            db.execute('UPDATE jobs SET state=?,reason=?,retry_failures=?,clean=NULL,output_sha256=NULL,mapping=NULL,audit=NULL,next_attempt=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                (state,error.reason,failures,self.clock()+retry_delay(failures) if state in {'retry','waiting'} else 0,job['id']))
            self.event(db,job['id'],state)
    def run_once(self):
        with self.locked():
            with database(self.path) as db:
                # Only one worker may run. A processing row at startup is a crashed job.
                interrupted=db.execute("SELECT id,interruptions FROM jobs WHERE state='processing'").fetchall()
                for row in interrupted:
                    count=row['interruptions']+1
                    state='held' if count>=MAX_ATTEMPTS else 'retry'
                    db.execute("UPDATE jobs SET state=?,reason=?,interruptions=?,next_attempt=0 WHERE id=?",
                        (state,'interrupted_retry_limit' if state=='held' else 'interrupted',count,row['id']))
                    self.event(db,row['id'],'held' if state=='held' else 'recovered_interrupted')
            input_errors=self.scan()
            with database(self.path) as db:
                ready=[dict(r) for r in db.execute("SELECT * FROM jobs WHERE state='ready'")]
            for job in ready:
                try:self.publish(job)
                except sanitizer.Hold as error:self.set_failure(job,error)
            with database(self.path) as db:
                ids=[r['id'] for r in db.execute("SELECT id FROM jobs WHERE state='queued' OR (state IN ('retry','waiting') AND next_attempt<=?) ORDER BY created_at,id",(self.clock(),))]
            for ident in ids:
                with database(self.path) as db:
                    row=dict(db.execute('SELECT * FROM jobs WHERE id=?',(ident,)).fetchone())
                    if row['state']=='waiting' and row['reason'] not in INFRASTRUCTURE_REASONS:
                        db.execute("UPDATE jobs SET state='held',reason='invalid_waiting_state' WHERE id=?",(ident,));continue
                    db.execute("UPDATE jobs SET state='processing',attempts=attempts+1,updated_at=CURRENT_TIMESTAMP WHERE id=?",(ident,))
                    row['attempts']+=1;self.event(db,ident,'processing')
                self.crash_hook('after_claim',row)
                try:
                    result=self.processor(row['original'],row['reference'])
                    with database(self.path) as db:
                        db.execute("UPDATE jobs SET state='ready',clean=?,output_sha256=?,mapping=?,audit=?,fingerprint=?,reason='checks_passed',retry_failures=0,interruptions=0 WHERE id=?",
                            (result.raw,hashlib.sha256(result.raw).hexdigest(),json.dumps(result.mapping),json.dumps(result.audit),self.fingerprint,ident))
                        self.event(db,ident,'checks_passed')
                    self.crash_hook('after_ready',row)
                    with database(self.path) as db:job=dict(db.execute('SELECT * FROM jobs WHERE id=?',(ident,)).fetchone())
                    self.publish(job)
                except sanitizer.Hold as error:self.set_failure(row,error)
                except Exception:self.set_failure(row,sanitizer.Hold('internal_error'))
            with database(self.path) as db:
                jobs=[dict(r) for r in db.execute('SELECT * FROM jobs')]
            for job in jobs:self.exception_file(job)
            result=self.status();result['input_errors']=input_errors
            return result
    def status(self):
        with database(self.path) as db:
            states={r[0]:r[1] for r in db.execute('SELECT state,count(*) FROM jobs GROUP BY state')}
            reasons={r[0]:r[1] for r in db.execute("SELECT reason,count(*) FROM jobs WHERE state IN ('held','retry','waiting') GROUP BY reason")}
            next_retry=db.execute("SELECT min(next_attempt) FROM jobs WHERE state IN ('retry','waiting') AND reason='model_unavailable'").fetchone()[0]
            arrivals=db.execute('SELECT count(*) FROM arrivals').fetchone()[0]
        return dict(scope='synthetic',jobs=sum(states.values()),arrivals=arrivals,states=states,exceptions=reasons,next_model_retry_at=next_retry)
    def retry(self):
        with self.locked(),database(self.path) as db:
            db.execute("UPDATE jobs SET next_attempt=0 WHERE state='retry' OR (state='waiting' AND reason='model_unavailable')")


def production_processor(model_name,sanitizer_module=None):
    if sanitizer_module is None:sanitizer_module=policy_module(DEFAULT_POLICY)
    detector=sanitizer_module.LocalDetector();model=sanitizer_module.LocalModel(model_name)
    import importlib.metadata
    versions={name:importlib.metadata.version(name) for name in ['presidio-analyzer','spacy','en-core-web-sm']}
    # Use the installed manifest even during an outage, so new source messages
    # can still be queued and marked for retry without forwarding anything.
    import re
    if not re.fullmatch(r'[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+',model_name):raise ValueError('Use an installed library model:tag')
    name,tag=model_name.split(':')
    manifest=ROOT/'.runtime/models/manifests/registry.ollama.ai/library'/name/tag
    if not manifest.is_file():raise ValueError('Selected local model is not installed')
    manifest_hash=hashlib.sha256(manifest.read_bytes()).hexdigest()
    pdf_path=ROOT/'pdf_text.py';pdf_hash=hashlib.sha256(pdf_path.read_bytes()).hexdigest()
    pdf_version=importlib.metadata.version('pypdf')
    def process(raw,reference):
        if hashlib.sha256(manifest.read_bytes()).hexdigest()!=manifest_hash:raise sanitizer.Hold('model_manifest_changed')
        if hashlib.sha256(pdf_path.read_bytes()).hexdigest()!=pdf_hash or importlib.metadata.version('pypdf')!=pdf_version:raise sanitizer.Hold('pdf_processor_changed')
        try:return sanitizer_module.sanitize(raw,reference,detector,model)
        except sanitizer_module.Retryable as e:raise sanitizer.Retryable(e.reason) from e
        except sanitizer_module.Hold as e:raise sanitizer.Hold(e.reason) from e
    dependencies={}
    for name in getattr(sanitizer_module,'DEPENDENCIES',()):
        path=(ROOT/name).resolve()
        if not path.is_relative_to(ROOT):raise ValueError('Sanitizer dependency must be project-local')
        dependencies[name]=hashlib.sha256(path.read_bytes()).hexdigest()
    value=dict(dependencies=dependencies,sanitizer=hashlib.sha256(Path(sanitizer_module.__file__).read_bytes()).hexdigest(),
               parser=hashlib.sha256((ROOT/'screener.py').read_bytes()).hexdigest(),
               model_settings=getattr(model,'settings',None),
               content_parser=hashlib.sha256((ROOT/'mail_content.py').read_bytes()).hexdigest(),
               pdf_processor=pdf_hash,
               pdf_library=pdf_version,model=manifest_hash,versions=versions)
    # Numeric diagnostics only; no source text, response content or alias mappings.
    process.model_metrics=getattr(model,'metrics',[])
    process.model_settings=dict(getattr(model,'settings',{}))
    return process,hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT/'data/flow-demo-final')
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('init');sub.add_parser('status');sub.add_parser('retry')
    for command in ['run','watch']:
        cmd=sub.add_parser(command);cmd.add_argument('--model',default=sanitizer.MODEL)
        cmd.add_argument('--policy',choices=sorted(POLICIES),default=DEFAULT_POLICY)
        if command=='watch':cmd.add_argument('--poll',type=float,default=1)
    args=p.parse_args()
    try:
        root=initialize(args.root)
        if args.command in {'run','watch'}:
            processor,fingerprint=production_processor(args.model,sanitizer_module=policy_module(args.policy))
            pipeline=Pipeline(root,processor,fingerprint)
            previous=None
            while True:
                current=json.dumps(pipeline.run_once(),sort_keys=True)
                if current!=previous:
                    print(current,flush=True);previous=current
                if args.command=='run':break
                time.sleep(max(.1,args.poll))
        else:
            pipeline=Pipeline(root,None,'status-only')
            if args.command=='retry':pipeline.retry()
            print(json.dumps(pipeline.status()),flush=True)
    except KeyboardInterrupt:pass
    except (ValueError,OSError,sqlite3.Error) as e:p.error(str(e))

if __name__=='__main__':main()
