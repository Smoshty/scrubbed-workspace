"""Managed checked-only reader snapshots and a separate local exception report."""
from contextlib import closing
import hashlib
import json
from pathlib import Path
import re
import secrets
import sqlite3
import time

from assistant_inbox import InboxError,encode,local_root,read_regular
from filtered_inbox import export,FilteredInbox
from mail_pipeline import atomic_file
from synthetic_mailbox import BoundaryError,MailboxUnavailable

SCOPE='synthetic-managed-reader'
REASONS={'refresh_in_progress','refresh_failed','mailbox_unavailable','provider_response_invalid',None}


def reader_root(source):
    source=local_root(source)
    return local_root(source.with_name(source.name+'-reader'))


def manifest(root):
    root=local_root(root);path=root/'current.json'
    if path.is_symlink():raise InboxError('Invalid reader storage')
    if not path.exists():return dict(schema=1,scope=SCOPE,snapshot=None,sha256=None,state='unavailable',reason=None,messages=0,verified_at=None)
    value=json.loads(read_regular(path))
    if not isinstance(value,dict) or set(value)!={'schema','scope','snapshot','sha256','state','reason','messages','verified_at'} or value['schema']!=1 or value['scope']!=SCOPE:raise InboxError('Invalid reader manifest')
    if value['state'] not in {'current','stale','unavailable'} or value['reason'] not in REASONS or type(value['messages']) is not int or not 0<=value['messages']<=1000:raise InboxError('Invalid reader status')
    if value['snapshot'] is None:
        if value['sha256'] is not None or value['messages']!=0 or value['verified_at'] is not None or value['state']!='unavailable':raise InboxError('Invalid empty reader')
    elif not isinstance(value['snapshot'],str) or not re.fullmatch(r'[0-9a-f]{32}\.json',value['snapshot']) or not isinstance(value['sha256'],str) or not re.fullmatch(r'[0-9a-f]{64}',value['sha256']) or type(value['verified_at']) not in {int,float}:raise InboxError('Invalid reader snapshot')
    return value


def save_manifest(root,value):
    root=local_root(root);root.mkdir(mode=0o700,parents=True,exist_ok=True)
    path=root/'current.json'
    if path.is_symlink():raise InboxError('Invalid reader storage')
    atomic_file(path,encode(value))


def stale(source,reason):
    root=reader_root(source);value=manifest(root)
    value.update(state='stale' if value['snapshot'] else 'unavailable',reason=reason)
    save_manifest(root,value)
    return value


def refresh(source,client,identity,clock=time.time):
    root=reader_root(source)
    # Mark the old snapshot stale before any network read or new publication.
    # A crash now preserves its immutable bytes and an honest refresh status.
    previous=stale(source,'refresh_in_progress')
    snapshots=local_root(root/'snapshots');snapshots.mkdir(mode=0o700,exist_ok=True)
    target=snapshots/(secrets.token_hex(16)+'.json')
    try:
        count=export(source,target,client,identity)
        raw=read_regular(target);digest=hashlib.sha256(raw).hexdigest()
        reuse=False
        if previous['sha256']==digest:
            try:reuse=hashlib.sha256(read_regular(local_root(snapshots/previous['snapshot']))).hexdigest()==digest
            except (OSError,InboxError):pass
        if reuse:target.unlink();name=previous['snapshot']
        else:name=target.name
        value=dict(schema=1,scope=SCOPE,snapshot=name,sha256=digest,state='current',reason=None,messages=count,verified_at=clock())
        save_manifest(root,value)
        return value
    except (OSError,ValueError,KeyError,TypeError,sqlite3.Error,BoundaryError) as error:
        target.unlink(missing_ok=True)
        return stale(source,'mailbox_unavailable' if isinstance(error,MailboxUnavailable) else 'refresh_failed')


def status(source):
    value=manifest(reader_root(source))
    return {key:value[key] for key in ['state','reason','messages','verified_at']}


def read(root,tool,arguments):
    root=local_root(root);value=manifest(root)
    if value['snapshot'] is None:
        if tool!='list_messages' or arguments!={}:raise InboxError('No verified reader snapshot')
        from filtered_inbox import NOTICE
        result=dict(notice=NOTICE,messages=[])
    else:
        path=local_root(root/'snapshots'/value['snapshot'])
        if hashlib.sha256(read_regular(path)).hexdigest()!=value['sha256']:raise InboxError('Reader snapshot changed')
        result=FilteredInbox(path).call(tool,arguments)
        if len(FilteredInbox(path).call('list_messages',{})['messages'])!=value['messages']:raise InboxError('Reader count changed')
    result['freshness']={key:value[key] for key in ['state','reason','messages','verified_at']}
    return result


EXPLANATIONS={
    'instruction_injection':'The message contains instructions that prevent safe automatic processing.',
    'model_unavailable':'The local privacy checker is unavailable. Processing will retry automatically.',
    'destination_reconciliation_conflict':'The destination copy does not match the checked copy. Delivery is blocked.',
    'submission_unacknowledged':'Delivery has not been confirmed. The worker will check the destination before resending.',
    'reconciliation_unavailable':'The destination cannot be checked yet. The worker will retry without assuming delivery.',
    'reconciliation_unknown':'The destination cannot confirm whether the copy exists. No resend is authorized.',
}


def exceptions(source,identity):
    # This report is local only. It has no release/retry or assistant capability.
    from mailbox_bridge import stored_status
    recorded=stored_status(source,identity)
    source=Path(source).absolute()
    with closing(sqlite3.connect((source/'state.sqlite3').as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute("SELECT j.reference,j.state,j.reason,j.next_attempt,d.state,d.reason,d.next_attempt FROM jobs j LEFT JOIN delivery d ON j.id=d.job_id ORDER BY j.rowid").fetchall()
    groups=dict(held=[],waiting=[],delivery=[])
    for ref,state,reason,due,delivery,delivery_reason,delivery_due in rows:
        if state=='held':group='held';next_attempt=None
        elif state in {'retry','waiting','processing','queued'}:group='waiting';next_attempt=due
        elif state=='ready' and delivery in {'pending','uncertain','blocked'}:group='delivery';reason=delivery_reason;next_attempt=delivery_due
        else:continue
        if not isinstance(ref,str) or not re.fullmatch(r'[0-9a-f]{32}',ref):raise InboxError('Invalid local reference')
        code=reason if isinstance(reason,str) and re.fullmatch(r'[a-z_]{1,80}',reason) else 'not_yet_checked'
        explanation=EXPLANATIONS.get(code, 'This message could not be fully checked and stays held. Its original is preserved.' if group=='held' else 'This message is waiting for processing or delivery confirmation. No unchecked copy is published.')
        if group=='held' and code=='model_unavailable':explanation='This older hold does not retry automatically. Its original is preserved.'
        groups[group].append(dict(reference=ref,reason=code,explanation=explanation,next_attempt=next_attempt))
    return dict(scope='synthetic-local-exceptions',connection=recorded['connection'],**groups)
